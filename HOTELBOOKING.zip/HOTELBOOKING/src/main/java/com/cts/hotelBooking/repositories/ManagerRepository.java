package com.cts.hotelBooking.repositories;

public interface ManagerRepository {
}
