package com.cts.hotelBooking.controller;

import com.cts.hotelBooking.entities.Hotel;
import com.cts.hotelBooking.entities.Room;
import com.cts.hotelBooking.repositories.HotelRepository;
import com.cts.hotelBooking.service.RoomService;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/rooms")
public class RoomController {
    @Autowired
    private RoomService roomService;
    @Autowired
    private HotelRepository hotelRepository;

    @GetMapping("/available")
    public ResponseEntity<List<Room>> getAvailableRooms(
            @RequestParam Long hotelId,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate checkInDate,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate checkOutDate
    ) {
        List<Room> rooms = roomService.getAvailableRooms(hotelId, checkInDate, checkOutDate);
        return ResponseEntity.ok(rooms);
    }

//     Add a new room
    @PostMapping("/addRooms")
    public ResponseEntity<Room> addRoom(@RequestBody Room room) {
        return ResponseEntity.ok(roomService.addRoom(room));
    }

    @PutMapping("/update/{roomId}")
    public ResponseEntity<Room> updateRoom(@PathVariable Long roomId, @RequestBody Room updatedRoom) {
        Room room = roomService.updateRoom(roomId, updatedRoom);
        return ResponseEntity.ok(room);
    }


    // Get a room by ID
    @GetMapping("/getRoomById/{roomId}")
    public ResponseEntity<Room> getRoom(@PathVariable Long roomId) {
        return ResponseEntity.ok(roomService.getRoomById(roomId));
    }



    //     Get all rooms by hotel ID
    @GetMapping("/getAllRoomsByHotelId/{hotelId}")
    public ResponseEntity<List<Room>> getRoomsByHotel(@PathVariable Long hotelId) {
        return ResponseEntity.ok(roomService.getRoomsByHotel(hotelId));
    }



    // Delete a room by ID
//    @DeleteMapping("/{roomId}")
//    public ResponseEntity<String> deleteRoom(@PathVariable Long roomId) {
//        roomService.deleteRoomWithDependencies(roomId);
//        return ResponseEntity.ok("Room deleted successfully.");
//    }

    // Search rooms by feature (Example: "Sea View", "Balcony")
    @GetMapping("/searchByFeature")
    public ResponseEntity<List<Room>> searchRoomsByFeature(@RequestParam String feature) {
        return ResponseEntity.ok(roomService.searchRoomsByFeature(feature));
    }

    // Filter rooms by price range
    @GetMapping("/filterByPrice")
    public ResponseEntity<List<Room>> filterRoomsByPrice(
            @RequestParam Double minPrice,
            @RequestParam Double maxPrice) {
        return ResponseEntity.ok(roomService.filterRoomsByPrice(minPrice, maxPrice));
    }

    // Pagination: Get rooms with page size
    @GetMapping("/paged")
    public ResponseEntity<List<Room>> getRoomsPaged(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "5") int size) {
        return ResponseEntity.ok(roomService.getRoomsPaged(page, size));
    }
    @DeleteMapping("/{roomId}")
    public ResponseEntity<Map<String, String>> deleteRoom(@PathVariable Long roomId) {
        Map<String, String> response = new HashMap<>();
        try {
            roomService.deleteRoom(roomId);
            response.put("message", "Room deleted successfully.");
            return ResponseEntity.ok(response); // ✅ Returns JSON response
        } catch (Exception e) {
            response.put("error", "Failed to delete room: " + e.getMessage());
            return ResponseEntity.badRequest().body(response);
        }
    }

}
