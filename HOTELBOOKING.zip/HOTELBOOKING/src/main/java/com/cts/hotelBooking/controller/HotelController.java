package com.cts.hotelBooking.controller;

import com.cts.hotelBooking.entities.Hotel;
import com.cts.hotelBooking.entities.Room;
import com.cts.hotelBooking.entities.User;
import com.cts.hotelBooking.repositories.RoomRepository;
import com.cts.hotelBooking.repositories.UserRepository;
import com.cts.hotelBooking.security.JwtUtil;
import com.cts.hotelBooking.service.HotelService;
import com.cts.hotelBooking.service.RoomService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

@RestController

public class HotelController {
    @Autowired
    private HotelService hotelService;

    @Autowired
    private UserRepository userRepository;
    @Autowired
    private JwtUtil jwtUtil;
    @GetMapping("/MANAGER/dashboard")
    public ResponseEntity<Map<String, Object>> getHotelDetails(@RequestHeader("Authorization") String token) {
        String email = jwtUtil.extractEmail(token);
        User manager = userRepository.findByEmail(email);

        if (manager == null || !manager.getRole().equals("MANAGER")) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(Map.of("error", "Access Denied"));
        }

        Hotel hotel = hotelService.getHotelByManagerId(manager.getUserId());

        if (hotel != null) {
            return ResponseEntity.ok(Map.of("hotel", hotel)); // ✅ Return hotel details as JSON
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(Map.of("message", "No hotel found")); // ✅ Returns 404 Not Found
        }
    }

    @PostMapping("/MANAGER/addHotel")
    public ResponseEntity<Hotel> addHotel(@RequestHeader("Authorization") String token, @RequestBody Hotel hotel) {
        String email = jwtUtil.extractEmail(token); // Extract email from JWT
        User manager = userRepository.findByEmail(email); // Retrieve User object

        if (manager == null || !manager.getRole().equals("MANAGER")) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(null); // Ensure only MANAGER can add a hotel
        }

        hotel.setManagerId(manager.getUserId()); // Correctly set managerId from User entity
        return ResponseEntity.ok(hotelService.addHotel(hotel));
        }

    @GetMapping("/MANAGER/{hotelId}")
    public ResponseEntity<?> getManagerHotel(@RequestHeader("Authorization") String token) {
        String email = jwtUtil.extractEmail(token);
        User manager = userRepository.findByEmail(email);

        if (manager == null || !manager.getRole().equals("MANAGER")) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body("Access Denied");
        }

        Hotel hotel = hotelService.getHotelByManagerId(manager.getUserId());

        if (hotel != null) {
            return ResponseEntity.ok(Map.of("hotelId", hotel.getHotelId(), "hotel", hotel)); // ✅ Returns hotelId
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(Map.of("message", "No hotel found"));
        }
    }


    // Get all hotels
    @GetMapping("/MANAGER/admin")
    public ResponseEntity<List<Hotel>> getAllHotels() {
        return ResponseEntity.ok(hotelService.getAllHotels());
    }

    // Update a hotel
    @PutMapping("/update/{hotelId}")
    public ResponseEntity<Hotel> updateHotel(@PathVariable Long hotelId, @RequestBody Hotel updatedHotel) {
        return ResponseEntity.ok(hotelService.updateHotel(hotelId, updatedHotel));
    }

    // Delete a hotel
    @DeleteMapping("/hotels/delete/{hotelId}")
    public ResponseEntity<String> deleteHotel(@PathVariable Long hotelId) {
        hotelService.deleteHotel(hotelId);
        return ResponseEntity.ok("Hotel deleted successfully!");
    }

    @GetMapping("/user/search/location")
    public ResponseEntity<List<Hotel>> searchByLocation(@RequestParam String location) {
        return ResponseEntity.ok(hotelService.searchHotelsByLocation(location));
    }

    // Search hotels by a single amenity
    @GetMapping("/search/amenity")
    public ResponseEntity<List<Hotel>> searchByAmenity(@RequestParam String amenity) {
        return ResponseEntity.ok(hotelService.searchHotelsByAmenity(amenity));
    }


    // Search hotels by multiple amenities
    @GetMapping("/search/amenities")
    public ResponseEntity<List<Hotel>> searchByAmenities(@RequestParam List<String> amenities) {
        return ResponseEntity.ok(hotelService.searchHotelsByAmenities(amenities));
    }


    @GetMapping("/hotels/search/available")
    public ResponseEntity<List<Hotel>> searchHotelsWithAvailableRooms(
            @RequestParam String checkInDate,
            @RequestParam String checkOutDate) {

        LocalDate checkIn = LocalDate.parse(checkInDate);
        LocalDate checkOut = LocalDate.parse(checkOutDate);

        List<Hotel> hotels = hotelService.findHotelsWithAvailableRoom(checkIn, checkOut);
        return ResponseEntity.ok(hotels);
    }

    @GetMapping("/MANAGER/search/name")public ResponseEntity<List<Hotel>> serchByHotelName(@RequestParam String name){
        return ResponseEntity.ok(hotelService.searchHotelByName(name));
    }
}
