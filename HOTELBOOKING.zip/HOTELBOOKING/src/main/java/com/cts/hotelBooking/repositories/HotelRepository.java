package com.cts.hotelBooking.repositories;

import com.cts.hotelBooking.entities.Hotel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface HotelRepository extends JpaRepository<Hotel, Long> {

    // Search hotels by location (case-insensitive)
    @Query("SELECT h FROM Hotel h WHERE LOWER(h.location) LIKE LOWER(CONCAT('%', :location, '%'))")
    List<Hotel> findByLocation(@Param("location") String location);
    // Search hotels by amenities (custom query)
    @Query("SELECT h FROM Hotel h JOIN h.amenities a WHERE LOWER(a) LIKE LOWER(CONCAT('%', :amenity, '%'))")
    List<Hotel> findByAmenity(@Param("amenity") String amenity);

    // Search hotels by multiple amenities
    @Query("SELECT h FROM Hotel h JOIN h.amenities a WHERE LOWER(a) IN :amenities")
    List<Hotel> findByAmenitiesIn(@Param("amenities") List<String> amenities);

    Hotel findByManagerId(Long managerId);

    List<Hotel> findAll();

    List<Hotel> findByName(String name);
}
