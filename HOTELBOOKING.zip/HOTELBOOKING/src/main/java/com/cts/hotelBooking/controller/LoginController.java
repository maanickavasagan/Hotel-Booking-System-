package com.cts.hotelBooking.controller;

import com.cts.hotelBooking.entities.User;
import com.cts.hotelBooking.service.ILoginService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api")
public class LoginController {

    private final ILoginService loginService;

    @Autowired
    public LoginController(ILoginService loginService) {
        this.loginService = loginService;
    }

    @PostMapping("/register")
    public ResponseEntity<Map<String, String>> registerEntity(@RequestBody User user) {
        Map<String, String> response = new HashMap<>();
        try {
            boolean isRegistered = loginService.addUser(user);
            response.put("message", isRegistered ? "Employee registered successfully" : "Email already exists");
            return isRegistered ? ResponseEntity.ok(response) : ResponseEntity.badRequest().body(response);
        } catch (IllegalArgumentException e) {
            response.put("message", e.getMessage());
            return ResponseEntity.status(409).body(response);
        }
    }

    @GetMapping("/userIdByEmail/{email}")
    public ResponseEntity<Long> getUserIdByEmail(@PathVariable String email) {
        Long userId = loginService.getUserIdByEmail(email);
        return (userId != null) ? ResponseEntity.ok(userId) : ResponseEntity.notFound().build();
    }

    @PostMapping("/admin/addManager")
    public ResponseEntity<Map<String, String>> addManager(@RequestBody User user) {
        boolean isAdded = loginService.addManager(user);
        Map<String, String> response = new HashMap<>();
        response.put("message", isAdded ? "Manager added successfully" : "Failed to add manager. Please try again.");
        return isAdded ? ResponseEntity.ok(response) : ResponseEntity.badRequest().body(response);
    }

    @PostMapping("/login")
    public ResponseEntity<?> loginUser(@RequestBody User user) {
        String token = loginService.authenticateUser(user.getEmail(), user.getPassword());
        String role = loginService.getUserRole(user.getEmail());

        if (token != null) {
            Map<String, String> response = new HashMap<>();
            response.put("token", token);
            response.put("role", role);
            return ResponseEntity.ok(response);
        }
        return ResponseEntity.status(401).body("Invalid email or password");
    }

    @PostMapping("/change-password")
    public ResponseEntity<Map<String, Object>> changePassword(@RequestBody Map<String, String> requestBody) {
        boolean isPasswordChanged = loginService.changePassword(
                requestBody.get("email"), requestBody.get("oldPassword"), requestBody.get("newPassword"));

        Map<String, Object> response = new HashMap<>();
        response.put("status", isPasswordChanged ? "success" : "error");
        response.put("message", isPasswordChanged ? "Password changed successfully" : "Invalid email or old password");
        return isPasswordChanged ? ResponseEntity.ok(response) : ResponseEntity.status(400).body(response);
    }

    @GetMapping("/all-users")
    public ResponseEntity<List<User>> getAllUsers() {
        return ResponseEntity.ok(loginService.getAllUsers());
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> getUserById(@PathVariable Long id) {
        User user = loginService.getUserById(id);
        return (user != null) ? ResponseEntity.ok(user) : ResponseEntity.status(404).body("User not found");
    }

    @PostMapping("/create-user")
    public ResponseEntity<?> createUser(@RequestBody User user) {
        return ResponseEntity.ok(loginService.createUser(user));
    }

    @PutMapping("/update-user/{id}")
    public ResponseEntity<?> updateUser(@PathVariable Long id, @RequestBody User user) {
        User updatedUser = loginService.updateUser(id, user);
        return (updatedUser != null) ? ResponseEntity.ok(updatedUser) : ResponseEntity.status(404).body("User not found");
    }

    @DeleteMapping("/delete-user/{id}")
    public ResponseEntity<?> deleteUser(@PathVariable Long id) {
        boolean isDeleted = loginService.deleteUser(id);
        return isDeleted ? ResponseEntity.ok("User deleted successfully") : ResponseEntity.status(404).body("User not found");
    }
}
