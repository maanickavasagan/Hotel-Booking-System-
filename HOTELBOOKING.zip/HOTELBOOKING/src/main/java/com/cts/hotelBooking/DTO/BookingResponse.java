package com.cts.hotelBooking.DTO;

import lombok.Data;

import java.time.LocalDate;

@Data
public class BookingResponse {
    private Long bookingId;
    private String status;
    private LocalDate checkInDate;
    private LocalDate checkOutDate;
    private String userName;
    private String roomType;
    private Double pricePerDay;
    private Double totalAmount;
}
