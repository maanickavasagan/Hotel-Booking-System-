package com.cts.hotelBooking.DTO;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.time.LocalDate;


@Data
public class BookingRequest {

    private Long userId;
    private Long hotelId;
    private Long roomId;
    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate checkInDate;
    @JsonFormat(pattern="yyyy-MM-dd")
    private LocalDate checkOutDate;
    private String currency;
}
