package com.cts.hotelBooking.security;

import io.jsonwebtoken.*;
import io.jsonwebtoken.security.Keys;
import org.springframework.stereotype.Component;

import java.security.Key;
import java.util.Date;

@Component
public class JwtUtil {

    private static final Key key = Keys.secretKeyFor(SignatureAlgorithm.HS256); // Ensure a consistent key
    private static final long EXPIRATION_TIME = 1000 * 60 * 60 * 10; // 10 hours

    // Generate a JWT token
    public String generateToken(String email, String role, long userId) {
        return Jwts.builder()
                .setSubject(email)
                .claim("role", role)
                .claim("userId", userId) // Ensure this is added
                .setIssuedAt(new Date())
                .setExpiration(new Date(System.currentTimeMillis() + EXPIRATION_TIME))
                .signWith(key)
                .compact();
    }

    // Extract email (subject) from the token
    public String extractEmail(String token) {
        return extractClaims(token).getSubject();
    }

    // Extract role from the token
    public String extractRole(String token) {
        return (String) extractClaims(token).get("role");
    }

    // Validate the token
    public boolean validateToken(String token, String email) {
        return email.equals(extractEmail(token)) && !isTokenExpired(token);
    }

    // Check if the token is expired
    private boolean isTokenExpired(String token) {
        return extractClaims(token).getExpiration().before(new Date());
    }

    // Safely extract claims with error handling
    private Claims extractClaims(String token) {
        String cleanToken = token.startsWith("Bearer ") ? token.substring(7) : token;

        try {
            return Jwts.parserBuilder().setSigningKey(key).build().parseClaimsJws(cleanToken).getBody();
        } catch (JwtException e) {
            throw new RuntimeException("Invalid or expired JWT token: " + e.getMessage());
        }
    }
}
