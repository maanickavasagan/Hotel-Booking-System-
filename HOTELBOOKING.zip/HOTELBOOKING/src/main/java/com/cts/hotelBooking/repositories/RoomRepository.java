package com.cts.hotelBooking.repositories;

import com.cts.hotelBooking.entities.Room;
import jakarta.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDate;
import java.util.List;

public interface RoomRepository extends JpaRepository<Room, Long> {
    // Add custom query methods if required
    @Query("SELECT r FROM Room r WHERE r.hotel.hotelId = :hotelId")
    List<Room> findByHotelHotelId(@Param("hotelId") Long hotelId);

    // ✅ Find rooms that match a feature inside the features list
    @Query("SELECT r FROM Room r JOIN r.features f WHERE f = :feature")
    List<Room> findRoomsByFeature(@Param("feature") String feature);

    // ✅ Find rooms within a price range
    List<Room> findByPriceBetween(Double minPrice, Double maxPrice);

    // ✅ Delete a room by its ID with transaction management
    @Transactional
    @Modifying
    @Query("DELETE FROM Room r WHERE r.roomId = :roomId")
    void deleteByRoomId(@Param("roomId") Long roomId);

    @Query("""
        SELECT r FROM Room r
        WHERE r.hotel.hotelId = :hotelId
        AND r.roomId NOT IN (
            SELECT b.room.roomId FROM Booking b
            WHERE b.hotel.hotelId = :hotelId
            AND b.status = 'CONFIRMED'
            AND (
                (b.checkInDate <= :checkOutDate AND b.checkOutDate >= :checkInDate)
            )
        )
    """)
    List<Room> findAvailableRooms(
            @Param("hotelId") Long hotelId,
            @Param("checkInDate") LocalDate checkInDate,
            @Param("checkOutDate") LocalDate checkOutDate
    );



}
