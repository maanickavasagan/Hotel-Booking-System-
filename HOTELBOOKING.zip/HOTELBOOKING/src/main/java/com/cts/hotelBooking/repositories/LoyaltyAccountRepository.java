//package com.cts.hotelBooking.repositories;
//
//import com.cts.hotelBooking.entities.LoyaltyAccount;
//import org.springframework.data.jpa.repository.JpaRepository;
//import org.springframework.stereotype.Repository;
//
//@Repository
//public interface LoyaltyAccountRepository extends JpaRepository<LoyaltyAccount, Long> {
//    // Correct method to find LoyaltyAccount by userId in the User entity
////    LoyaltyAccount findByUser_UserId(Long userId);
//
//}

package com.cts.hotelBooking.repositories;



import com.cts.hotelBooking.entities.LoyaltyAccount;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.Optional;

@Repository
public interface LoyaltyAccountRepository extends JpaRepository<LoyaltyAccount, Long> {
    Optional<LoyaltyAccount> findByUser_UserId(Long userId);
}