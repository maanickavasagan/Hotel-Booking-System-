package com.cts.hotelBooking.entities;

public class Manager {
}
