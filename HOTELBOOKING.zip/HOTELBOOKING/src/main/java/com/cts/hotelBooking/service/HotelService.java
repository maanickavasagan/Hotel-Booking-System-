package com.cts.hotelBooking.service;

import com.cts.hotelBooking.entities.Hotel;
import com.cts.hotelBooking.entities.Review;
import com.cts.hotelBooking.entities.Room;
import com.cts.hotelBooking.entities.User;
import com.cts.hotelBooking.repositories.HotelRepository;
import com.cts.hotelBooking.repositories.ReviewRepository;
import com.cts.hotelBooking.repositories.RoomRepository;
import com.cts.hotelBooking.repositories.UserRepository;
import com.cts.hotelBooking.security.JwtUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class HotelService {
    @Autowired
    private HotelRepository hotelRepository;
    @Autowired
    private RoomRepository roomRepository;
    @Autowired
    private ReviewRepository reviewRepository;
    @Autowired
    private UserRepository userRepository;
    @Autowired
    private JwtUtil jwtUtil;
    public Hotel addHotel(Hotel hotel) {
        return hotelRepository.save(hotel);
    }




    public Hotel getHotelById(Long hotelId) {
        return hotelRepository.findById(hotelId)
                .orElseThrow(() -> new RuntimeException("Hotel not found"));
    }

    public List<Hotel> getAllHotels() {
        return hotelRepository.findAll();
    }

    public Hotel updateHotel(Long hotelId, Hotel updatedHotel) {
        Hotel existingHotel = hotelRepository.findById(hotelId)
                .orElseThrow(() -> new RuntimeException("Hotel not found"));
        return hotelRepository.save(existingHotel);
    }
    public Hotel getHotelByManagerId(Long managerId) {
        return hotelRepository.findByManagerId(managerId);
    }

    public void deleteHotel(Long hotelId) {

        List<Room> rooms = roomRepository.findByHotelHotelId(hotelId);
        List<Review> reviews = reviewRepository.findByHotel_HotelId(hotelId);
        roomRepository.deleteAll(rooms);
        reviewRepository.deleteAll(reviews);
        hotelRepository.deleteById(hotelId);

    }

    public List<Hotel> searchHotelsByLocation(String location) {
        List<Hotel> l = hotelRepository.findByLocation(location);
        System.out.println(location);
        System.out.print(l);
        return hotelRepository.findByLocation(location);
    }

    public List<Hotel> searchHotelsByAmenity(String amenity) {
        return hotelRepository.findByAmenity(amenity);
    }

    public List<Hotel> searchHotelsByAmenities(List<String> amenities) {
        return hotelRepository.findByAmenitiesIn(amenities);
    }


    public List<Hotel> findHotelsWithAvailableRoom(LocalDate checkIn, LocalDate checkOut) {
        List<Hotel> allHotels = hotelRepository.findAll();

        return allHotels.stream()
                .filter(hotel -> hotel.getRooms().stream().anyMatch(room -> isRoomAvailable(room, checkIn, checkOut)))
                .collect(Collectors.toList());
    }

    private boolean isRoomAvailable(Room room, LocalDate checkIn, LocalDate checkOut) {
        // Room is available if it has no bookings that overlap with the requested dates
        return room.getBookings().stream().noneMatch(booking ->
                !(booking.getCheckOutDate().isBefore(checkIn) || booking.getCheckInDate().isAfter(checkOut))
        );
    }
    public List<Hotel> searchHotelByName(String name){
        return hotelRepository.findByName(name);
    }


}
