package com.cts.hotelBooking.service;

import com.cts.hotelBooking.entities.Review;
import java.util.List;

public interface IReviewService {
    Review addReview(Review review);
    List<Review> getReviewsByHotelId(Long hotelId);
    List<Review> getReviewsByUserId(Long userId);
    void deleteReview(Long reviewId);
    void deleteReviewsByHotelId(Long hotelId);
    Review updateReview(Long reviewId, Review updatedReview);
    Double getAverageRatingByHotelId(Long hotelId);
}
