package com.cts.hotelBooking.service;

import com.cts.hotelBooking.entities.User;
import java.util.List;

public interface ILoginService {
    boolean addManager(User user);
    boolean addUser(User user);
    String authenticateUser(String email, String rawPassword);
    String getUserRole(String email);
    boolean changePassword(String email, String oldPassword, String newPassword);
    Long getUserIdByEmail(String email);
    List<User> getAllUsers();
    User getUserById(Long id);
    User createUser(User user);
    User updateUser(Long id, User updatedUser);
    boolean deleteUser(Long id);
}
