package com.cts.hotelBooking.service;

import com.cts.hotelBooking.entities.Room;
import com.cts.hotelBooking.repositories.HotelRepository;
import com.cts.hotelBooking.repositories.RoomRepository;
import jakarta.persistence.EntityManager;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Service
public class RoomService {
    @Autowired
    private RoomRepository roomRepository;
    @Autowired
    private HotelRepository hotelRepository;
    @Autowired
    private EntityManager entityManager;


    public Room addRoom(Room room) {
        room.setHotel(room.getHotel());
        return roomRepository.save(room);
    }

    public Room getRoomById(Long roomId) {
        return roomRepository.findById(roomId)
                .orElseThrow(() -> new RuntimeException("Room not found"));
    }

    public List<Room> getRoomsByHotel(Long hotelId) {
        return roomRepository.findAll()
                .stream()
                .filter(room -> room.getHotel().getHotelId().equals(hotelId))
                .toList();
    }

    public Room updateRoom(Long roomId, Room updatedRoom) {
        Room existingRoom = roomRepository.findById(roomId)
                .orElseThrow(() -> new RuntimeException("Room not found"));

        existingRoom.setType(updatedRoom.getType());
        existingRoom.setPrice(updatedRoom.getPrice());
        existingRoom.setAvailability(updatedRoom.getAvailability());
        existingRoom.setFeatures(updatedRoom.getFeatures());

        return roomRepository.save(existingRoom);
    }

//    public List<Room> getAvailableRooms(Long hotelId, LocalDate checkIn, LocalDate checkOut) {
//        List<Room> rooms = roomRepository.findByHotel_HotelId(hotelId);
//        for (Room room : rooms) {
//            boolean isBooked = bookingRepository.existsByRoom_RoomIdAndStatusAndCheckInDateLessThanEqualAndCheckOutDateGreaterThanEqual(
//                    room.getRoomId(), "CONFIRMED", checkOut, checkIn
//            );
//            room.setAvailability(!isBooked); // Set availability directly on the entity
//        }
//        return rooms;
//    }




    public List<Room> getAvailableRooms(Long hotelId, LocalDate checkIn, LocalDate checkOut) {
        return roomRepository.findAvailableRooms(hotelId, checkIn, checkOut);
    }

    public void deleteRoom(Long roomId) {
        roomRepository.deleteById(roomId);
    }

    public List<Room> searchRoomsByFeature(String feature) {
        return roomRepository.findRoomsByFeature(feature);
    }


    public List<Room> filterRoomsByPrice(Double minPrice, Double maxPrice) {
        return roomRepository.findByPriceBetween(minPrice, maxPrice);
    }

    public List<Room> getRoomsPaged(int page, int size) {
        return roomRepository.findAll(PageRequest.of(page, size)).getContent();
    }

    @Transactional
    public void deleteRoomWithDependencies(Long roomId) {
        roomRepository.deleteById(roomId);
    }

}
