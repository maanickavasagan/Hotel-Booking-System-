package com.cts.hotelBooking.repositories;

import com.cts.hotelBooking.entities.Redemption;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RedemptionRepository extends JpaRepository<Redemption, Long> {
    // Add custom query methods if required
}
