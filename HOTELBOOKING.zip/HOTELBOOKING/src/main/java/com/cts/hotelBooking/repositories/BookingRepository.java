package com.cts.hotelBooking.repositories;

import com.cts.hotelBooking.entities.Booking;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDate;
import java.util.List;

public interface BookingRepository extends JpaRepository<Booking, Long> {
    // Add custom query methods if required
    @Query("SELECT b FROM Booking b WHERE b.room.roomId = :roomId AND b.status = 'CONFIRMED' " +
            "AND (:checkInDate BETWEEN b.checkInDate AND b.checkOutDate " +
            "OR :checkOutDate BETWEEN b.checkInDate AND b.checkOutDate " +
            "OR b.checkInDate BETWEEN :checkInDate AND :checkOutDate)")
    List<Booking> findConflictingBookings(@Param("roomId") Long roomId,
                                          @Param("checkInDate") LocalDate checkInDate,
                                          @Param("checkOutDate") LocalDate checkOutDate);



    boolean existsByRoom_RoomIdAndStatusAndCheckInDateLessThanEqualAndCheckOutDateGreaterThanEqual(
            Long roomId, String status, LocalDate checkOutDate, LocalDate checkInDate);

    List<Booking> findByHotel_HotelId(Long hotelId);
    void deleteByHotel_HotelId(Long hotelId);
    @Query("SELECT b FROM Booking b WHERE b.user.userId = :userId AND b.status = 'CONFIRMED'")
    List<Booking> findConfirmedBookingsByUser(@Param("userId") Long userId);
    List<Booking> findByHotelHotelIdAndStatus(Long hotelId, String status);


}
