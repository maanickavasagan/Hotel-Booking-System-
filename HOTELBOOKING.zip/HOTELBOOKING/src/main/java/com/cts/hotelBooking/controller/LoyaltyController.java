package com.cts.hotelBooking.controller;

import com.cts.hotelBooking.entities.LoyaltyAccount;
import com.cts.hotelBooking.entities.Redemption;
import com.cts.hotelBooking.entities.Room;
import com.cts.hotelBooking.repositories.RedemptionRepository;
import com.cts.hotelBooking.service.LoyaltyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
@RestController
@RequestMapping("/api/loyalty")
public class LoyaltyController {
    @Autowired
    private LoyaltyService loyaltyService;
    @PostMapping("/updatePoints/{userId}/{paymentAmount}/{lPoints}")
    public ResponseEntity<LoyaltyAccount> updatePointsBalance(@PathVariable Long userId, @PathVariable Double paymentAmount, @PathVariable Long lPoints) {
        if (paymentAmount == null || paymentAmount <= 0) {
            return ResponseEntity.badRequest().body(null);
        }
        LoyaltyAccount updatedAccount = loyaltyService.updatePointsBalance(userId, paymentAmount,lPoints);
        return ResponseEntity.ok(updatedAccount);
    }
    @GetMapping("/getRedeemablePoints/{userId}")
    public ResponseEntity<Integer> getRedeemablePoints(@PathVariable Long userId) {
        int redeemablePoints = loyaltyService.calculateRedeemablePoints(userId);
        return ResponseEntity.ok(redeemablePoints);
    }
    @PostMapping("/redeemPoints/{userId}/{pointsToRedeem}/{amount}")
    public ResponseEntity<Double> redeemPoints(@PathVariable Long userId, @PathVariable Integer pointsToRedeem,@PathVariable Double amount) {
        Double discountAmount = loyaltyService.redeemPoints(userId, pointsToRedeem,amount);
        return ResponseEntity.ok(discountAmount);
    }
}