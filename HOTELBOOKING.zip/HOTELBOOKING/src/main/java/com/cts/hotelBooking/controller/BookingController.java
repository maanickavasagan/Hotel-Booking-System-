
package com.cts.hotelBooking.controller;
import com.cts.hotelBooking.DTO.BookingRequest;
import com.cts.hotelBooking.entities.*;
import com.cts.hotelBooking.repositories.*;
import com.cts.hotelBooking.service.BookingService;
import com.cts.hotelBooking.service.PaymentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Validated
@RestController
@RequestMapping("api/client/bookings")
public class BookingController {
    @Autowired
    private BookingService bookingService;

    @Autowired
    private PaymentRepository paymentRepository;
    @Autowired
    private PaymentService paymentService;
    @Autowired
    private BookingRepository bookingRepository;
    @Autowired
    private RoomRepository roomRepository;
    @Autowired
    private HotelRepository hotelRepository;
    @Autowired
    private UserRepository userRepository;

    @GetMapping("/user/{userId}/history")
    public ResponseEntity<List<Booking>> getBookingHistoryByUserId(@PathVariable Long userId) {
        List<Booking> bookingHistory = bookingService.getBookingHistoryByUserId(userId);
        return ResponseEntity.ok(bookingHistory);
    }
    @GetMapping("/confirmed/{hotelId}")
    public ResponseEntity<List<Booking>> getConfirmedBookings(@PathVariable Long hotelId) {
        List<Booking> bookings = bookingService.getConfirmedBookingsByHotel(hotelId);

        if (bookings.isEmpty()) {
            return ResponseEntity.noContent().build(); // ✅ Returns 204 if no confirmed bookings
        }

        return ResponseEntity.ok(bookings); // ✅ Returns JSON response
    }


    @PostMapping("/create")
    public ResponseEntity<Map<String,Object>> createBooking(@RequestBody Map<String, Object> request) throws Exception {
        // Extract IDs from the request map
        System.out.println("Received booking request: " + request);

        Long hotelId = Long.valueOf(request.get("hotelId").toString());
        Long roomId = Long.valueOf(request.get("roomId").toString());
        Long userId = Long.valueOf(request.get("userId").toString());
        Long lPoints=Long.valueOf(request.get("loyaltyPoints").toString());

        String currency = request.get("currency").toString();
        LocalDate checkInDate = LocalDate.parse(request.get("checkInDate").toString());
        LocalDate checkOutDate = LocalDate.parse(request.get("checkOutDate").toString());

        // Fetch entities
        Hotel hotel = hotelRepository.findById(hotelId)
                .orElseThrow(() -> new RuntimeException("Hotel not found"));
        Room room = roomRepository.findById(roomId)
                .orElseThrow(() -> new RuntimeException("Room not found"));
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found"));

        // Create and set up Booking
        Booking booking = new Booking();
        booking.setHotel(hotel);
        booking.setRoom(room);
        booking.setUser(user);
        booking.setCheckInDate(checkInDate);
        booking.setCheckOutDate(checkOutDate);
        booking.setStatus("PENDING");

        Booking savedBooking = bookingRepository.save(booking);

        long numOfDays = ChronoUnit.DAYS.between(checkInDate, checkOutDate);
        if (numOfDays <= 0) {
            throw new RuntimeException("check-out date must be after the check-in date.");
        }
        List<Booking> conflicts = bookingRepository.findConflictingBookings(roomId, checkInDate, checkOutDate);
        if (!conflicts.isEmpty()) {
            throw new RuntimeException("Room is not available for the selected dates.");
        }
        double totalAmount = Double.parseDouble(request.get("totalPrice").toString());
        Long bookingId = savedBooking.getBookingId();
        String paymentUrl = paymentService.handlePayment(totalAmount, userId, bookingId, currency,lPoints);

        Map<String, Object> response = new HashMap<>();
        response.put("bookingId", bookingId);
        response.put("paymentUrl", paymentUrl);
        response.put("message", "Booking created. Proceed to payment.");
        response.put("totalDays", numOfDays);
        response.put("totalAmount", totalAmount);
        return ResponseEntity.ok(response);
    }
    // CONFIRM Booking after payment
    @PostMapping("/confirm/{bookingId}/{paymentId}")
    public ResponseEntity<String> confirmBooking(@RequestParam Long bookingId, @RequestParam Long paymentId) {

        Payment payment = paymentRepository.findById(paymentId)
                .orElseThrow(() -> new RuntimeException("Payment not found"));

        bookingService.confirmBooking(bookingId, payment);
        return ResponseEntity.ok("Booking confirmed and room marked as unavailable.");
    }

    // GET booking by ID
    @GetMapping("/{bookingId}")
    public ResponseEntity<Booking> getBookingById(@PathVariable Long bookingId) {
        Booking booking = bookingService.getBookingById(bookingId);
        return ResponseEntity.ok(booking);
    }

    @DeleteMapping("/hotel/{hotelId}")
    public ResponseEntity<Void> deleteBookingsByHotel(@PathVariable Long hotelId) {
        bookingService.deleteBookingsByHotelId(hotelId);
        return ResponseEntity.noContent().build();
    }

    // GET all bookings
    @GetMapping("/all")
    public ResponseEntity<List<Booking>> getAllBookings() {
        return ResponseEntity.ok(bookingService.getAllBookings());
    }

    // DELETE booking
    @PutMapping("/cancel/{bookingId}")
    public ResponseEntity<String>cancelBooking(@PathVariable Long bookingId)
    {
        Booking booking=bookingRepository.findById(bookingId).orElseThrow(() -> new RuntimeException("Booking not found"));
        LocalDate checkInDate= booking.getCheckInDate();
        LocalDate checkOutDate= booking.getCheckOutDate();
        LocalDate today=LocalDate.now();
        long daysLeft =ChronoUnit.DAYS.between(today,checkInDate);
        if(daysLeft<1){
            return ResponseEntity.badRequest().body("Cannot cancel booking within 24 hours of Check-in");
        }
        booking.setStatus("CANCELLED");
        booking.getRoom().setAvailability(true);
        roomRepository.save(booking.getRoom());
        bookingRepository.save(booking);
        return ResponseEntity.ok("Booking cancelled successfully");

    }
}
