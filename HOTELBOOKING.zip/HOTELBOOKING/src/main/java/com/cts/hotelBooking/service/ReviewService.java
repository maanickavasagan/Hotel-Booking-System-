package com.cts.hotelBooking.service;

import com.cts.hotelBooking.Exceptions.ResourceNotFoundException;
import com.cts.hotelBooking.entities.Review;
import com.cts.hotelBooking.repositories.ReviewRepository;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class ReviewService implements IReviewService {

    private final ReviewRepository reviewRepository;

    @Autowired
    public ReviewService(ReviewRepository reviewRepository) {
        this.reviewRepository = reviewRepository;
    }

    @Override
    public Review addReview(Review review) {
        review.setTimestamp(LocalDateTime.now());
        return reviewRepository.save(review);
    }

    @Override
    public List<Review> getReviewsByHotelId(Long hotelId) {
        List<Review> reviews = reviewRepository.findByHotel_HotelId(hotelId);
        if (reviews.isEmpty()) {
            throw new ResourceNotFoundException("No reviews found for hotel with ID:" + hotelId);
        }
        return reviews;
    }

    @Override
    public List<Review> getReviewsByUserId(Long userId) {
        List<Review> reviews = reviewRepository.findByUser_UserId(userId);
        if (reviews.isEmpty()) {
            throw new ResourceNotFoundException("No reviews found for user with ID:" + userId);
        }
        return reviews;
    }

    @Override
    public void deleteReview(Long reviewId) {
        if (!reviewRepository.existsById(reviewId)) {
            throw new ResourceNotFoundException("Review with ID: " + reviewId + " not found");
        }
        reviewRepository.deleteById(reviewId);
    }

    @Override
    public Review updateReview(Long reviewId, Review updatedReview) {
        Optional<Review> existingReviewOpt = reviewRepository.findById(reviewId);
        if (existingReviewOpt.isEmpty()) {
            throw new ResourceNotFoundException("Review with ID: " + reviewId + " not found");
        }
        Review existing = existingReviewOpt.get();
        existing.setRating(updatedReview.getRating());
        existing.setComment(updatedReview.getComment());
        existing.setTimestamp(LocalDateTime.now());
        return reviewRepository.save(existing);
    }

    @Override
    public Double getAverageRatingByHotelId(Long hotelId) {
        Double avg = reviewRepository.findAverageRatingByHotelId(hotelId);
        return avg != null ? avg : 0.0;
    }

    @Override
    @Transactional
    public void deleteReviewsByHotelId(Long hotelId) {
        reviewRepository.deleteByHotel_HotelId(hotelId);
    }
}
