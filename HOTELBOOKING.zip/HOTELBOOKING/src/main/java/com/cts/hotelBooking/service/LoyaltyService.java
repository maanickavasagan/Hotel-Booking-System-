
package com.cts.hotelBooking.service;
import com.cts.hotelBooking.entities.LoyaltyAccount;
import com.cts.hotelBooking.entities.User;
import com.cts.hotelBooking.repositories.LoyaltyAccountRepository;
import com.cts.hotelBooking.repositories.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.time.LocalDateTime;
import java.util.Optional;
@Service
public class LoyaltyService {
    @Autowired
    private LoyaltyAccountRepository loyaltyAccountRepository;
    @Autowired
    private UserRepository userRepository;
    public LoyaltyAccount updatePointsBalance(Long userId, Double paymentAmount, Long lPoints) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found"));
        Optional<LoyaltyAccount> loyaltyAccountOpt = loyaltyAccountRepository.findByUser_UserId(userId);
        LoyaltyAccount loyaltyAccount = loyaltyAccountOpt.orElseGet(() -> {
            LoyaltyAccount newAccount = new LoyaltyAccount();
            newAccount.setUser(user);
            newAccount.setPointsBalance(0);
            newAccount.setLastUpdated(LocalDateTime.now().toString()); // Ensuring the correct timestamp format
            return newAccount;
        });
        int earnedPoints = (int) (paymentAmount * 0.10); // 10% of payment as points
        loyaltyAccount.setPointsBalance((int) (loyaltyAccount.getPointsBalance() + earnedPoints - lPoints));
        return loyaltyAccountRepository.save(loyaltyAccount);
    }

    public int calculateRedeemablePoints(Long userId) {
        Optional<LoyaltyAccount> loyaltyAccountOpt = loyaltyAccountRepository.findByUser_UserId(userId);
        return loyaltyAccountOpt.map(LoyaltyAccount::getPointsBalance).orElse(0);
    }
    public Double redeemPoints(Long userId, Integer pointsToRedeem, Double amount) {
        Optional<LoyaltyAccount> loyaltyAccountOpt = loyaltyAccountRepository.findByUser_UserId(userId);
        if (loyaltyAccountOpt.isEmpty()) {
            throw new RuntimeException("Loyalty account not found");}
        LoyaltyAccount loyaltyAccount = loyaltyAccountOpt.get();
        if (loyaltyAccount.getPointsBalance() < pointsToRedeem) {throw new RuntimeException("Not enough points for redemption");}
        Double discountAmount =(amount) -(pointsToRedeem * 0.5);
        loyaltyAccount.setPointsBalance(loyaltyAccount.getPointsBalance() - pointsToRedeem);
        loyaltyAccountRepository.save(loyaltyAccount);
        return discountAmount;
    }
}

