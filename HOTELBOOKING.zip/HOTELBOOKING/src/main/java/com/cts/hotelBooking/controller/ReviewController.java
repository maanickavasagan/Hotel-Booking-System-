package com.cts.hotelBooking.controller;

import com.cts.hotelBooking.entities.Review;
import com.cts.hotelBooking.service.IReviewService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/Reviews")
public class ReviewController {

    private final IReviewService reviewService;

    @Autowired
    public ReviewController(IReviewService reviewService) {
        this.reviewService = reviewService;
    }

    @PostMapping("/postReview")
    public ResponseEntity<Review> addReview(@RequestBody Review review) {
        return ResponseEntity.ok(reviewService.addReview(review));
    }

    @GetMapping("/hotel/{hotelId}")
    public ResponseEntity<List<Review>> getReviewsByHotel(@PathVariable Long hotelId) {
        return ResponseEntity.ok(reviewService.getReviewsByHotelId(hotelId));
    }

    @GetMapping("/user/{userId}")
    public ResponseEntity<List<Review>> getReviewsByUser(@PathVariable Long userId) {
        return ResponseEntity.ok(reviewService.getReviewsByUserId(userId));
    }

    @DeleteMapping("/{reviewId}")
    public ResponseEntity<Void> deleteReview(@PathVariable Long reviewId) {
        reviewService.deleteReview(reviewId);
        return ResponseEntity.ok().build();
    }

    @DeleteMapping("/hotel/{hotelId}")
    public ResponseEntity<Void> deleteReviewsByHotel(@PathVariable Long hotelId) {
        reviewService.deleteReviewsByHotelId(hotelId);
        return ResponseEntity.ok().build();
    }

    @PutMapping("/updateReview/{reviewId}")
    public ResponseEntity<Review> updateReview(@PathVariable Long reviewId, @RequestBody Review updatedReview) {
        return ResponseEntity.ok(reviewService.updateReview(reviewId, updatedReview));
    }

    @GetMapping("/hotel/{hotelId}/average-rating")
    public ResponseEntity<Double> getAverageRating(@PathVariable Long hotelId) {
        return ResponseEntity.ok(reviewService.getAverageRatingByHotelId(hotelId));
    }
}
