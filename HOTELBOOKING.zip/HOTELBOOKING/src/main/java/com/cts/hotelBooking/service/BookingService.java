
package com.cts.hotelBooking.service;
import com.cts.hotelBooking.DTO.BookingRequest;
import com.cts.hotelBooking.Exceptions.ResourceNotFoundException;
import com.cts.hotelBooking.entities.*;
import com.cts.hotelBooking.repositories.BookingRepository;
import com.cts.hotelBooking.repositories.HotelRepository;
import com.cts.hotelBooking.repositories.RoomRepository;
import com.cts.hotelBooking.repositories.UserRepository;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BookingService {

    @Autowired
    private BookingRepository bookingRepository;

    @Autowired
    private RoomRepository roomRepository;

    @Autowired
    private UserRepository userRepository;
    @Autowired
    private HotelRepository hotelRepository;

    @Transactional
    public Booking createBooking(BookingRequest request) {
        Room room = roomRepository.findById(request.getRoomId())
                .orElseThrow(() -> new RuntimeException("Room not found"));
        Hotel hotel=hotelRepository.findById(request.getHotelId()).orElseThrow(()-> new RuntimeException("Hotel not found"));
        if(!room.getHotel().getHotelId().equals(hotel.getHotelId())){
            throw new RuntimeException("Selected room does not belong to the selected hotel.");
        }

        List <Booking> conflicts = bookingRepository.findConflictingBookings(room.getRoomId(),request.getCheckInDate(),request.getCheckInDate());
        if(!conflicts.isEmpty()){
            throw new RuntimeException("Room is already booked for the selected dates");
        }
        User user = userRepository.findById(request.getUserId())
                .orElseThrow(() -> new RuntimeException("User not found"));

        Booking booking = new Booking();
        booking.setUser(user);
        booking.setRoom(room);
        booking.setCheckInDate(request.getCheckInDate());
        System.out.println(request.getCheckInDate());
        booking.setCheckOutDate(request.getCheckOutDate());
        System.out.println(request.getCheckOutDate());
        booking.setStatus("PENDING");

        return bookingRepository.save(booking);
    }
    public List<Booking> getBookingHistoryByUserId(Long userId) {
        List<Booking> bookings = bookingRepository.findConfirmedBookingsByUser(userId);
        if (bookings.isEmpty()) {
            throw new ResourceNotFoundException("No booking history found for user with ID: " + userId);
        }
        return bookings;
    }
    public List<Booking> getConfirmedBookingsByHotel(Long hotelId) {
        return bookingRepository.findByHotelHotelIdAndStatus(hotelId, "CONFIRMED");
    }
    @Transactional
    public void confirmBooking(Long bookingId, Payment payment) {
        Booking booking = bookingRepository.findById(bookingId)
                .orElseThrow(() -> new RuntimeException("Booking not found"));

        if (!"PENDING".equalsIgnoreCase(booking.getStatus())) {
            throw new IllegalStateException("Booking already processed");
        }

        Room room = booking.getRoom();
        if (!room.getAvailability()) {
            throw new RuntimeException("Room is no longer available");
        }

        booking.setStatus("CONFIRMED");
        booking.setPayment(payment);
        bookingRepository.save(booking);

        room.setAvailability(false);
        roomRepository.save(room);
    }

    // NEW: Get booking by ID
    public Booking getBookingById(Long bookingId) {
        return bookingRepository.findById(bookingId)
                .orElseThrow(() -> new RuntimeException("Booking not found"));
    }

    // NEW: Get all bookings
    public List<Booking> getAllBookings() {
        return bookingRepository.findAll();
    }

    @Transactional
    public void deleteBookingsByHotelId(Long hotelId) {
        List<Booking> bookings = bookingRepository.findByHotel_HotelId(hotelId);
        for (Booking booking : bookings) {
            // If booking was confirmed, free the room
            if ("CONFIRMED".equalsIgnoreCase(booking.getStatus())) {
                Room room = booking.getRoom();
                room.setAvailability(true);
                roomRepository.save(room);
            }
        }
        bookingRepository.deleteByHotel_HotelId(hotelId);
    }

    // NEW: Delete booking
public void deleteBooking(Long bookingId) {
        Booking booking = bookingRepository.findById(bookingId)
                .orElseThrow(() -> new RuntimeException("Booking not found"));

        // If booking was confirmed, free the room
        if ("CONFIRMED".equalsIgnoreCase(booking.getStatus())) {
            Room room = booking.getRoom();
            room.setAvailability(true);
            roomRepository.save(room);
        }

        bookingRepository.deleteById(bookingId);
    }
}
