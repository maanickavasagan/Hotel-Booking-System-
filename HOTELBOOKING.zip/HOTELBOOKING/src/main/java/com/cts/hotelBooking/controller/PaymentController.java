
package com.cts.hotelBooking.controller;
import com.cts.hotelBooking.entities.Booking;
import com.cts.hotelBooking.entities.Payment;
import com.cts.hotelBooking.entities.User;
import com.cts.hotelBooking.repositories.BookingRepository;
import com.cts.hotelBooking.repositories.PaymentRepository;
import com.cts.hotelBooking.repositories.RoomRepository;
import com.cts.hotelBooking.service.LoyaltyService;
import com.cts.hotelBooking.service.PaymentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.view.RedirectView;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/payments")
public class PaymentController {
    @Autowired
    private PaymentService paymentService;
    @Autowired
    private BookingRepository bookingRepository;
    @Autowired
    private RoomRepository roomRepository;
    @Autowired
    private PaymentRepository paymentRepository;
    @Autowired
    private LoyaltyService loyaltyService;

    private final RestTemplate restTemplate = new RestTemplate();

    public PaymentController(PaymentService paymentService) {
        this.paymentService = paymentService;
    }
    @PostMapping("/checkout")
    public ResponseEntity<Map<String,Object>>checkout(@RequestParam Double amount,@RequestParam Long userId, @RequestParam Long bookingId, @RequestParam String currency,@RequestParam Long lPoints ) throws Exception{
        String paymentUrl =paymentService.handlePayment(amount,userId,bookingId,currency,lPoints);
        Map<String, Object> response=new HashMap<>();
        response.put("paymentUrl",paymentUrl);
        response.put("message","Proceed to payment");
        return ResponseEntity.ok(response);
    }
    @GetMapping("/success")
    public RedirectView paymentSuccess(@RequestParam Long bookingId, @RequestParam Long paymentId,@RequestParam Long lPoints) {
        try {
            //  Retrieve booking and payment details
            Booking booking = bookingRepository.findById(bookingId)
                    .orElseThrow(() -> new RuntimeException("Booking not found"));
            Payment payment = paymentRepository.findById(paymentId)
                    .orElseThrow(() -> new RuntimeException("Payment not found"));

            //  Update booking and payment status
            booking.setStatus("CONFIRMED");
            booking.setPayment(payment);
            booking.getRoom().setAvailability(false);
            payment.setStatus("CONFIRMED");

            User user=booking.getUser();
            Long userId= user.getUserId();
            //  Save updated records
            paymentRepository.save(payment);
            bookingRepository.save(booking);
            roomRepository.save(booking.getRoom());
            loyaltyService.updatePointsBalance(userId,payment.getAmount(),lPoints);




            System.out.println("Payment confirmed for Booking ID: " + bookingId);

            //  Redirect user to the frontend booking confirmation page

            String redirectUrl = "http://localhost:4200/user/success/" ;
            return new RedirectView(redirectUrl);

        } catch (Exception e) {
            System.err.println("Error processing payment success: " + e.getMessage());

            //  Redirect to an error page or return response
            return new RedirectView("http://localhost:4200/user/failure");
        }
    }



    @GetMapping("/cancel")
    public ResponseEntity<Map<String, Object>> paymentFailure() {
        Map<String, Object> response = new HashMap<>();
        response.put("status", "FAILED");
        response.put("message", "Payment Failed. Please try again.");

        return ResponseEntity.ok(response);

    }

}
