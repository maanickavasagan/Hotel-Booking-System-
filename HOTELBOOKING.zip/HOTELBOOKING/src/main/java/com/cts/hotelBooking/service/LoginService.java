package com.cts.hotelBooking.service;

import com.cts.hotelBooking.entities.User;
import com.cts.hotelBooking.security.JwtUtil;
import com.cts.hotelBooking.repositories.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class LoginService implements ILoginService {

    private final UserRepository userRepository;
    private final JwtUtil jwtUtil;

    @Autowired
    public LoginService(UserRepository userRepository, JwtUtil jwtUtil) {
        this.userRepository = userRepository;
        this.jwtUtil = jwtUtil;
    }

    @Override
    public boolean addManager(User user) {
        Optional<User> existingUser = Optional.ofNullable(userRepository.findByEmail(user.getEmail()));
        if (existingUser.isPresent()) {
            throw new IllegalArgumentException("Email already registered for another manager or user");
        }

        user.setRole("MANAGER");
        userRepository.save(user);
        return true;
    }

    @Override
    public boolean addUser(User user) {
        Optional<User> existingUser = Optional.ofNullable(userRepository.findByEmail(user.getEmail()));
        if (existingUser.isPresent()) {
            throw new IllegalArgumentException("Email already registered");
        }

        if (user.getRole() == null || user.getRole().isEmpty()) {
            user.setRole("CLIENT");
        }

        userRepository.save(user);
        return true;
    }

    @Override
    public String authenticateUser(String email, String rawPassword) {
        User user = userRepository.findByEmail(email);
        if (user != null && rawPassword.equals(user.getPassword())) {
            return jwtUtil.generateToken(user.getEmail(), user.getRole(), user.getUserId());
        }
        return null;
    }

    @Override
    public String getUserRole(String email) {
        User user = userRepository.findByEmail(email);
        return (user != null) ? user.getRole() : null;
    }

    @Override
    public boolean changePassword(String email, String oldPassword, String newPassword) {
        User user = userRepository.findByEmail(email);
        if (user != null && user.getPassword().equals(oldPassword)) {
            user.setPassword(newPassword);
            userRepository.save(user);
            return true;
        }
        return false;
    }

    @Override
    public Long getUserIdByEmail(String email) {
        return userRepository.findUserIdByEmail(email);
    }

    @Override
    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    @Override
    public User getUserById(Long id) {
        return userRepository.findById(id).orElse(null);
    }

    @Override
    public User createUser(User user) {
        return userRepository.save(user);
    }

    @Override
    public User updateUser(Long id, User updatedUser) {
        return userRepository.findById(id).map(existingUser -> {
            existingUser.setEmail(updatedUser.getEmail());
            existingUser.setPassword(updatedUser.getPassword());
            existingUser.setName(updatedUser.getName());
            existingUser.setContactNumber(updatedUser.getContactNumber());
            existingUser.setRole(updatedUser.getRole());
            return userRepository.save(existingUser);
        }).orElse(null);
    }

    @Override
    public boolean deleteUser(Long id) {
        if (userRepository.existsById(id)) {
            userRepository.deleteById(id);
            return true;
        }
        return false;
    }
}
