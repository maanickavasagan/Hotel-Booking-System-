package com.cts.hotelBooking.repositories;

import com.cts.hotelBooking.entities.Review;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface ReviewRepository extends JpaRepository<Review, Long> {
    // Add custom query methods if required
    List<Review> findByHotel_HotelId(Long hotelId);
    List<Review> findByUser_UserId(Long userId);
    void deleteByHotel_HotelId(Long hotelId);


    @Query("SELECT AVG(r.rating) FROM Review r WHERE r.hotel.hotelId = :hotelId")
    Double findAverageRatingByHotelId(@Param("hotelId") Long hotelId);


}
