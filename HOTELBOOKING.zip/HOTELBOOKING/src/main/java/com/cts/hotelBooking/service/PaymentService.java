
package com.cts.hotelBooking.service;
import com.cts.hotelBooking.entities.Payment;
import com.cts.hotelBooking.entities.User;
import com.cts.hotelBooking.repositories.PaymentRepository;
import com.cts.hotelBooking.repositories.UserRepository;
import com.stripe.Stripe;
import com.stripe.model.checkout.Session;
import com.stripe.param.checkout.SessionCreateParams;
import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
@Service
public class PaymentService {
    @Autowired
    private PaymentRepository paymentRepository;
    @Autowired
    private UserRepository userRepository;
    @Value("${Stripe.api.secret.key}")
    private String stripeSecretKey;
    @PostConstruct
    public void init(){
        Stripe.apiKey=stripeSecretKey;
    }
    public String handlePayment(double  amount, Long userId, Long bookingId,String currency,Long lPoints) throws Exception{
        User user=userRepository.findById(userId).orElseThrow(() -> new RuntimeException("User not found"));
        Payment payment =new Payment();
        payment.setAmount(amount);
        payment.setUser(user);
        payment.setStatus("PENDING");
        payment.setPaymentMethod("stripe");
        Payment savedPayment = paymentRepository.save(payment);
        SessionCreateParams params = SessionCreateParams.builder()
                .setMode(SessionCreateParams.Mode.PAYMENT)
                .setSuccessUrl("http://localhost:8082/payments/success?bookingId="+bookingId+"&paymentId="+savedPayment.getPaymentId()+"&lPoints="+lPoints)
                .setCancelUrl("http://localhost:8082/payments/cancel")
                .putMetadata("userId", userId.toString())
                .putMetadata("bookingId",bookingId.toString())
                .addLineItem(SessionCreateParams.LineItem.builder()
                        .setQuantity(1L)
                        .setPriceData(
                                SessionCreateParams.LineItem.PriceData.builder()
                                        .setCurrency(currency.toLowerCase())
                                        .setUnitAmount((long) amount*100)
                                        .setProductData(
                                                SessionCreateParams.LineItem.PriceData.ProductData.builder()
                                                        .setName("Hotel Booking Payment")
                                                        .build())
                                        .build())
                        .build())
                .build();
        Session session = Session.create(params);


        return session.getUrl();
    }
}
