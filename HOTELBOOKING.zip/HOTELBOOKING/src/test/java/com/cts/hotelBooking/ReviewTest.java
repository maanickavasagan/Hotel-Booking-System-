package com.cts.hotelBooking;
import com.cts.hotelBooking.controller.ReviewController;
import com.cts.hotelBooking.entities.Hotel;
import com.cts.hotelBooking.entities.User;
import com.cts.hotelBooking.repositories.ReviewRepository;
import com.cts.hotelBooking.service.ReviewService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;
import com.cts.hotelBooking.entities.Review;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import javax.security.auth.callback.ConfirmationCallback;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

public class ReviewTest {

    private Review review;

    @BeforeEach
    void setUp() {
        review = new Review(1L, 4.5, "Great service!", LocalDateTime.now(), new User(), new Hotel());
    }

    @Test
    void testReviewEntity() {
        assertNotNull(review);
        assertEquals(4.5, review.getRating());
        assertEquals("Great service!", review.getComment());
    }
}
class ReviewRepositoryTest {

    @Mock
    private ReviewRepository reviewRepository;

    @InjectMocks
    private ReviewService reviewService; // Assuming Reviewservice is the service class

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this); // Initialize mocks
    }

    @Test
    void testFindByHotel_HotelId() {
        // Arrange
        Long hotelId = 1L;
        List<Review> mockReviews = new ArrayList<>();
        mockReviews.add(new Review(1L, 4.5, "Great stay!", null, null, null));
        when(reviewRepository.findByHotel_HotelId(hotelId)).thenReturn(mockReviews);

        // Act
        List<Review> reviews = reviewService.getReviewsByHotelId(hotelId);

        // Assert
        assertEquals(1, reviews.size());
        assertEquals(4.5, reviews.get(0).getRating());
        assertEquals("Great stay!", reviews.get(0).getComment());

        // Verify interaction
        verify(reviewRepository, times(1)).findByHotel_HotelId(hotelId);
    }
}
class ReviewServiceTest {

    @Mock
    private ReviewRepository reviewRepository;

    @InjectMocks
    private ReviewService reviewService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this); // Initialize mocks
    }

    @Test
    void testGetReviewsByHotelId() {
        // Arrange
        Long hotelId = 1L;
        List<Review> mockReviews = new ArrayList<>();
        mockReviews.add(new Review(1L, 4.5, "Great stay!", null, null, null));
        when(reviewRepository.findByHotel_HotelId(hotelId)).thenReturn(mockReviews);

        // Act
        List<Review> reviews = reviewService.getReviewsByHotelId(hotelId);

        // Assert
        assertEquals(1, reviews.size());
        assertEquals(4.5, reviews.get(0).getRating());
        assertEquals("Great stay!", reviews.get(0).getComment());

        // Verify interaction
        verify(reviewRepository, times(1)).findByHotel_HotelId(hotelId);
    }
}
class ReviewControllerTest {

    @Mock
    private ReviewService reviewService;

    @InjectMocks
    private ReviewController reviewController;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this); // Initialize mocks
    }
    @Test
    void testGetReviewsByHotelId() {
        // Arrange
        Long hotelId = 1L;
        List<Review> mockReviews = new ArrayList<>();
        mockReviews.add(new Review(1L, 4.5, "Great stay!", null, null, null));
        when(reviewService.getReviewsByHotelId(hotelId)).thenReturn(mockReviews);

        // Act
        ResponseEntity<List<Review>> response = reviewController.getReviewsByHotel(hotelId);

        // Assert
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(1, response.getBody().size());
        assertEquals(4.5, response.getBody().get(0).getRating());
        assertEquals("Great stay!", response.getBody().get(0).getComment());

        // Verify interaction
        verify(reviewService, times(1)).getReviewsByHotelId(hotelId);
    }
    @Test
    void testAddReview() {
        // Arrange
        Review review = new Review(1L, 4.5, "Excellent service!", null, null, null);
        when(reviewService.addReview(review)).thenReturn(review);

        // Act
        ResponseEntity<Review> response = reviewController.addReview(review);

        // Assert
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(4.5, response.getBody().getRating());
        assertEquals("Excellent service!", response.getBody().getComment());

        // Verify interaction
        verify(reviewService, times(1)).addReview(review);
    }
    @Test
    void testDeleteReview() {
        // Arrange
        Long reviewId = 1L;
        doNothing().when(reviewService).deleteReview(reviewId);

        // Act
        ResponseEntity<Void> response = reviewController.deleteReview(reviewId);

        // Assert
        assertEquals(HttpStatus.OK, response.getStatusCode());

        // Verify interaction
        verify(reviewService, times(1)).deleteReview(reviewId);
    }
}