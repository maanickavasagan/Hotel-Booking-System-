package com.cts.hotelBooking;

import com.cts.hotelBooking.controller.LoyaltyController;
import com.cts.hotelBooking.entities.LoyaltyAccount;
import com.cts.hotelBooking.service.LoyaltyService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.ResponseEntity;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class LoyaltyTest {

    @Mock
    private LoyaltyService loyaltyService;

    @InjectMocks
    private LoyaltyController loyaltyController;

    @Test
    void testUpdatePointsBalance_Success() {
        Long userId = 1L;
        Double paymentAmount = 500.0;
        Long lPoints = 100L;
        LoyaltyAccount mockAccount = new LoyaltyAccount();

        when(loyaltyService.updatePointsBalance(userId, paymentAmount, lPoints)).thenReturn(mockAccount);

        ResponseEntity<LoyaltyAccount> response = loyaltyController.updatePointsBalance(userId, paymentAmount, lPoints);

        assertEquals(200, response.getStatusCodeValue());
        assertNotNull(response.getBody());
    }

    @Test
    void testUpdatePointsBalance_InvalidPayment() {
        Long userId = 1L;
        Double paymentAmount = -500.0; // Invalid case
        Long lPoints = 100L;

        ResponseEntity<LoyaltyAccount> response = loyaltyController.updatePointsBalance(userId, paymentAmount, lPoints);

        assertEquals(400, response.getStatusCodeValue());
        assertNull(response.getBody());
    }

    @Test
    void testGetRedeemablePoints() {
        Long userId = 1L;
        when(loyaltyService.calculateRedeemablePoints(userId)).thenReturn(500);

        ResponseEntity<Integer> response = loyaltyController.getRedeemablePoints(userId);

        assertEquals(200, response.getStatusCodeValue());
        assertEquals(500, response.getBody());
    }

    @Test
    void testRedeemPoints() {
        Long userId = 1L;
        Integer pointsToRedeem = 100;
        Double amount = 200.0;

        when(loyaltyService.redeemPoints(userId, pointsToRedeem, amount)).thenReturn(50.0);

        ResponseEntity<Double> response = loyaltyController.redeemPoints(userId, pointsToRedeem, amount);

        assertEquals(200, response.getStatusCodeValue());
        assertEquals(50.0, response.getBody());
    }
}
