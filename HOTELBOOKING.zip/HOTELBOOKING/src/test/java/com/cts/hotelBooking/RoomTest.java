package com.cts.hotelBooking;

import com.cts.hotelBooking.controller.RoomController;
import com.cts.hotelBooking.entities.Room;
import com.cts.hotelBooking.service.RoomService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.util.Collections;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

class RoomTest {

    private MockMvc mockMvc;

    @Mock
    private RoomService roomService;

    @InjectMocks
    private RoomController roomController;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        mockMvc = MockMvcBuilders.standaloneSetup(roomController).build();
    }

    /**  Test: Get Available Rooms **/
    @Test
    void testGetAvailableRooms() throws Exception {
        when(roomService.getAvailableRooms(anyLong(), any(), any())).thenReturn(Collections.emptyList());

        mockMvc.perform(get("/rooms/available?hotelId=1&checkInDate=2025-06-10&checkOutDate=2025-06-15"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$").isEmpty());
    }

    /**  Test: Add Room **/
    @Test
    void testAddRoom() throws Exception {
        Room room = new Room();
        room.setRoomId(101L);
        room.setPrice(100.0);
        room.setType("Deluxe");

        when(roomService.addRoom(any(Room.class))).thenReturn(room);

        mockMvc.perform(post("/rooms/addRooms")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{ \"roomId\": 101, \"price\": 100.0, \"type\": \"Deluxe\" }"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.roomId").value(101))
                .andExpect(jsonPath("$.type").value("Deluxe"));
    }

    /**  Test: Update Room **/
    @Test
    void testUpdateRoom() throws Exception {
        Room updatedRoom = new Room();
        updatedRoom.setRoomId(101L);
        updatedRoom.setPrice(150.0);
        updatedRoom.setType("Executive");

        when(roomService.updateRoom(anyLong(), any(Room.class))).thenReturn(updatedRoom);

        mockMvc.perform(put("/rooms/update/101")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{ \"price\": 150.0, \"type\": \"Executive\" }"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.price").value(150.0))
                .andExpect(jsonPath("$.type").value("Executive"));
    }

    /**  Test: Get Room By ID **/
    @Test
    void testGetRoomById() throws Exception {
        Room room = new Room();
        room.setRoomId(101L);
        when(roomService.getRoomById(anyLong())).thenReturn(room);

        mockMvc.perform(get("/rooms/getRoomById/101"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.roomId").value(101));
    }

    /**  Test: Get Rooms By Hotel **/
    @Test
    void testGetRoomsByHotel() throws Exception {
        when(roomService.getRoomsByHotel(anyLong())).thenReturn(Collections.emptyList());

        mockMvc.perform(get("/rooms/getAllRoomsByHotelId/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$").isEmpty());
    }

    /**  Test: Search Rooms By Feature **/
    @Test
    void testSearchRoomsByFeature() throws Exception {
        when(roomService.searchRoomsByFeature(anyString())).thenReturn(Collections.emptyList());

        mockMvc.perform(get("/rooms/searchByFeature?feature=Balcony"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$").isEmpty());
    }

    /** Test: Filter Rooms By Price **/
    @Test
    void testFilterRoomsByPrice() throws Exception {
        when(roomService.filterRoomsByPrice(anyDouble(), anyDouble())).thenReturn(Collections.emptyList());

        mockMvc.perform(get("/rooms/filterByPrice?minPrice=100&maxPrice=300"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$").isEmpty());
    }

    @Test
    void testDeleteRoom() throws Exception {
        mockMvc.perform(delete("/rooms/101"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.message").value("Room deleted successfully."));

        verify(roomService, times(1)).deleteRoom(101L);
    }
}
