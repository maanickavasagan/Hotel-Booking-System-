package com.cts.hotelBooking;

import com.cts.hotelBooking.controller.LoginController;
import com.cts.hotelBooking.entities.User;
import com.cts.hotelBooking.service.LoginService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.ResponseEntity;

import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class LoginTest {

    @Mock
    private LoginService loginService;

    @InjectMocks
    private LoginController loginController;


    @Test
    void testRegisterUser_Success() {
        User user = new User();
        user.setEmail("test@example.com");
        user.setPassword("password");

        when(loginService.addUser(user)).thenReturn(true);

        ResponseEntity<Map<String, String>> response = loginController.registerEntity(user);

        assertEquals(200, response.getStatusCode().value());
        assertEquals("Employee registered successfully", response.getBody().get("message"));
    }

    @Test
    void testRegisterUser_EmailAlreadyExists() {
        User user = new User();
        user.setEmail("existing@example.com");
        user.setPassword("password");

        when(loginService.addUser(user)).thenReturn(false);

        ResponseEntity<Map<String, String>> response = loginController.registerEntity(user);

        assertEquals(400, response.getStatusCode().value());
        assertEquals("Email already exists", response.getBody().get("message"));
    }

    /**  Test User Login */
    @Test
    void testLogin_Success() {
        User user = new User();
        user.setEmail("test@example.com");
        user.setPassword("password");

        when(loginService.authenticateUser(user.getEmail(), user.getPassword())).thenReturn("mockToken");
        when(loginService.getUserRole(user.getEmail())).thenReturn("CLIENT");

        ResponseEntity<?> response = loginController.loginUser(user);

        assertEquals(200, response.getStatusCode().value());
        assertNotNull(response.getBody());
        assertTrue(response.getBody() instanceof Map);
    }

    @Test
    void testLogin_Failure() {
        User user = new User();
        user.setEmail("wrong@example.com");
        user.setPassword("wrongpass");

        when(loginService.authenticateUser(user.getEmail(), user.getPassword())).thenReturn(null);

        ResponseEntity<?> response = loginController.loginUser(user);

        assertEquals(401, response.getStatusCode().value());
        assertEquals("Invalid email or password", response.getBody());
    }

    /**  Test Changing Password */
    @Test
    void testChangePassword_Success() {
        Map<String, String> request = new HashMap<>();
        request.put("email", "test@example.com");
        request.put("oldPassword", "oldpass");
        request.put("newPassword", "newpass");

        when(loginService.changePassword("test@example.com", "oldpass", "newpass")).thenReturn(true);

        ResponseEntity<Map<String, Object>> response = loginController.changePassword(request);

        assertEquals(200, response.getStatusCode().value());
        assertEquals("success", response.getBody().get("status"));
    }

    @Test
    void testChangePassword_Failure() {
        Map<String, String> request = new HashMap<>();
        request.put("email", "test@example.com");
        request.put("oldPassword", "wrongpass");
        request.put("newPassword", "newpass");

        when(loginService.changePassword("test@example.com", "wrongpass", "newpass")).thenReturn(false);

        ResponseEntity<Map<String, Object>> response = loginController.changePassword(request);

        assertEquals(400, response.getStatusCode().value());
        assertEquals("error", response.getBody().get("status"));
    }
}
