import { Component, OnInit } from '@angular/core';
import { AdminService } from './admin.service'; // ✅ Import the AdminService
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-admin',
  imports: [FormsModule, CommonModule],
  standalone: true,
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {
  hotels: any[] = []; // ✅ Store hotel data
  newManager = { name: '', email: '', password: '',contactNumber:'' }
  errorMessage = '';

  constructor(private adminService: AdminService) {}

  ngOnInit() {
    this.fetchAllHotels();
  }
  addManager() {
    console.log("Sending manager data:", JSON.stringify(this.newManager, null, 2)); // ✅ Debugging log
  
    this.adminService.addManager(this.newManager).subscribe({
      next: (response) => {
        console.log("Manager added successfully:", response);
        alert(response.message); // ✅ Fetch message from JSON object
      },
      error: (error) => {
        console.error("Error adding manager:", error);
        this.errorMessage = error.error?.error || "Failed to add manager."; // ✅ Extract error from JSON object
      }
    });
  }
  
  
  fetchAllHotels() {
    this.adminService.getAllHotels().subscribe({
      next: (response) => {
        console.log("Fetched hotels:", response);
        this.hotels = response;
      },
      error: (error) => {
        console.error("Error fetching hotels:", error);
        this.errorMessage = "Failed to fetch hotel details.";
      }
    });
  }
}
