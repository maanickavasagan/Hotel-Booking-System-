import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AdminService {
  private apiUrl = 'http://localhost:8082'; // ✅ API Endpoint

  constructor(private http: HttpClient) {}

  getAllHotels(): Observable<any> {
    const headers = new HttpHeaders({ 'Authorization': localStorage.getItem('jwtToken') || '' });
    return this.http.get(`${this.apiUrl}/MANAGER/admin`, { headers }); // ✅ Fetch hotels with auth headers
  }
  addManager(manager: any): Observable<any> {
    const headers = new HttpHeaders({
      'Authorization': localStorage.getItem('jwtToken') || '',
      'Content-Type': 'application/json'
    });
  
    return this.http.post(`http://localhost:8082/api/admin/addManager`, JSON.stringify(manager), { headers });
  }
  
}
