import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { UserComponent } from './user/user.component';
import { AdminComponent } from './admin/admin.component';
import { ManagerComponent } from './manager/manager.component';
import { CreateHotelComponent } from './manager/create-hotel/create-hotel.component';
import { ManageHotelComponent } from './manager/manage-hotel/manage-hotel.component';
import { RoomsComponent } from './manager/rooms/rooms.component';
import { LoginComponent } from './auth/component/login/login.component';
import { RegisterComponent } from './auth/component/register/register.component';
import { BookingComponent } from './user/booking/booking.component';
import { SuccessComponent } from './user/success/success.component';
import { FailureComponent } from './user/failure/failure.component';
import { ProfileComponent } from './user/profile/profile.component';
import { BookingHistoryComponent } from './user/booking-history/booking-history.component';
import { RoleGuard } from '../auth.guard';
import { AccessDeniedComponentTsComponent } from './access-denied.component.ts/access-denied.component.ts.component';

export const routes: Routes = [
  { path: '', redirectTo: '/user', pathMatch: 'full' },
  { path: 'auth/login', component: LoginComponent },
  { path: 'auth/register', component: RegisterComponent },
  {
    path: 'admin',
    component: AdminComponent,
    canActivate: [RoleGuard],
    data: { expectedRole: 'ADMIN' } // Only Admins can access this
  },
  {
    path: 'manager',
    component: ManagerComponent,
    canActivate: [RoleGuard],
    data: { expectedRole: 'MANAGER' }, // Only Managers can access this
    children: [
      { path: 'create-hotel', component: CreateHotelComponent },
      { path: 'manage-hotel', component: ManageHotelComponent },
      { path: 'rooms', component: RoomsComponent }
    ]
  },
  { path: 'user', component: UserComponent },
  { path: 'user/booking/:hotelId', component: BookingComponent },
  { path: 'user/success', component: SuccessComponent },
  { path: 'user/failure', component: FailureComponent },
  { path: 'user/profile', component: ProfileComponent },
  { path: 'user/booking-history', component: BookingHistoryComponent },
  { path: 'access-denied', component: AccessDeniedComponentTsComponent }, // Route for access denied page
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {}
