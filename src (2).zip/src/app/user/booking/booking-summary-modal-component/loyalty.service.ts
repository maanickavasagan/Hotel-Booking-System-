import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class LoyaltyService {
  constructor(private http: HttpClient) {}

  getUserIdByEmail(email: string): Observable<number> {
    return this.http.get<number>(`http://localhost:8082/api/userIdByEmail/${email}`);
  }

  getRedeemablePoints(userId: number): Observable<number> {
    console.log(userId);
    return this.http.get<number>(`http://localhost:8082/api/loyalty/getRedeemablePoints/${userId}`);
  }
}