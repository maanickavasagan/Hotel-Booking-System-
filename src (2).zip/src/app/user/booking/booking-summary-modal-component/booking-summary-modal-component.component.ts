import { Component, Input, Output, EventEmitter, OnInit } from '@angular/core';
import { LoyaltyService } from './loyalty.service';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-booking-summary-modal',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './booking-summary-modal-component.component.html',
  styleUrls: ['./booking-summary-modal-component.component.css']
})
export class BookingSummaryModalComponent implements OnInit {
  @Input() hotelId!: number;
  @Input() selectedRoom: any;
  @Input() bookingData: any;
  @Input() numberOfDays!: number;
  @Input() totalPrice!: number;
  @Output() close = new EventEmitter<void>();
  @Output() proceed = new EventEmitter<number>();

  userId: number = 0;
  loyaltyPoints: number = 0;
  redeemPoints: number = 0;
  redeemableAmount: number = 0;
  finalPrice: number = 0;
  maxRedeemablePoints: number = 0;

  constructor(private loyaltyService: LoyaltyService) {}

  ngOnInit() {
    let userId = this.bookingData?.userId;
    if (!userId) {
      const email = localStorage.getItem('email') || sessionStorage.getItem('email');
      if (email) {
        this.loyaltyService.getUserIdByEmail(email).subscribe(id => {
          userId = id;
          this.bookingData.userId = id; // <-- Directly update bookingData.userId
          this.fetchLoyaltyPoints(userId);
        });
        return;
      }
    }
    if (userId) {
      this.fetchLoyaltyPoints(userId);
    } else {
      this.finalPrice = this.totalPrice;
    }
  }

  fetchLoyaltyPoints(userId: number) {
    this.loyaltyService.getRedeemablePoints(userId).subscribe(points => {
      this.loyaltyPoints = points;
      this.maxRedeemablePoints = Math.min(
        Math.floor(this.loyaltyPoints / 100) * 100,
        Math.floor(this.totalPrice / 20) * 100
      );
      this.redeemPoints = 0;
      this.calculateRedeemable();
    });
  }

  incrementPoints() {
    if (this.redeemPoints + 100 <= this.maxRedeemablePoints) {
      this.redeemPoints += 100;
      this.calculateRedeemable();
    }
  }

  decrementPoints() {
    if (this.redeemPoints - 100 >= 0) {
      this.redeemPoints -= 100;
      this.calculateRedeemable();
    }
  }

  calculateRedeemable() {
    this.redeemableAmount = (this.redeemPoints / 100) * 20;
    this.finalPrice = Math.max(this.totalPrice - this.redeemableAmount, 0);
  }
 
  onProceed() {
    this.proceed.emit(this.redeemPoints);
  }

  onClose() {
    this.close.emit();
  }
}