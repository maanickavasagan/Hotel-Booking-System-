import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BookingSummaryModalComponent } from './booking-summary-modal-component.component';

describe('BookingSummaryModalComponentComponent', () => {
  let component: BookingSummaryModalComponent;
  let fixture: ComponentFixture<BookingSummaryModalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [BookingSummaryModalComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(BookingSummaryModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
