import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ReviewServiceService } from './review-details/review-service.service';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { BookingSummaryModalComponent } from "./booking-summary-modal-component/booking-summary-modal-component.component";
import { ReviewDetailsComponent } from "./review-details/review-details.component";
import { UserService } from '../user.service';

@Component({
  selector: 'app-booking',
  imports: [FormsModule, CommonModule, BookingSummaryModalComponent, ReviewDetailsComponent],
  templateUrl: './booking.component.html',
  styleUrls: ['./booking.component.css']
})
export class BookingComponent implements OnInit {
  hotelId: number = 0;
  userId: number = 0;
  rooms: any[] = [];
  filteredRooms: any[] = [];
  selectedRoom: any = null;
  paymentUrl: string = ""; 
  showModal: boolean = false;
  numberOfDays: number = 0;
  totalPrice: number = 0;
  paymentSuccess: boolean = false;
  paymentFailed: boolean = false;
  bookingId: number = 0;
  userIdLoaded: boolean = false;
  today: string = new Date().toISOString().split('T')[0];
  // For sidebar reviews
  reviews: any[] = [];
  sidebarReviews: any[] = [];

  bookingData = {
    hotelId: 0,
    roomId: 0,
    userId: 0,
    currency: "INR",
    checkInDate: "",
    checkOutDate: "",
    totalPrice: 0,
    loyaltyPoints: 0
  };

  constructor(
    private route: ActivatedRoute,
    private userService: UserService,
    private reviewService: ReviewServiceService
  ) {}

  @ViewChild('bookingSummary') bookingSummary!: ElementRef;

  ngOnInit() {
    const hotelIdStr = this.route.snapshot.paramMap.get('hotelId');
    this.hotelId = hotelIdStr ? Number(hotelIdStr) : 0;

    // Read check-in and check-out from query params
    this.route.queryParamMap.subscribe(params => {
      const checkIn = params.get('checkIn');
      const checkOut = params.get('checkOut');
      if (checkIn) this.bookingData.checkInDate = checkIn;
      if (checkOut) this.bookingData.checkOutDate = checkOut;
      if (checkIn && checkOut) this.onDateChange();
    });

    const email = localStorage.getItem('email');
    if (email) {
      this.userService.getUserIdByEmail(email).subscribe({
        next: (id) => {
          this.userId = id;
          this.userIdLoaded = true;
        },
        error: () => {
          this.userId = 0;
          this.userIdLoaded = true;
        }
      });
    }
    

    if (this.hotelId > 0) {
      this.getRoomsForHotel();
      this.loadSidebarReviews();
    }
  }

  loadSidebarReviews() {
    this.reviewService.getReviewsByHotel(this.hotelId).subscribe({
      next: (data) => {
        this.reviews = data || [];
        this.sidebarReviews = this.reviews.slice(0, 2);
      },
      error: () => {
        this.reviews = [];
        this.sidebarReviews = [];
      }
    });
  }

  showFullReviews() {
    const el = document.getElementById('full-reviews');
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  }

  onDateChange() {
    if (!this.bookingData.checkInDate || !this.bookingData.checkOutDate) {
      this.filteredRooms = [];
      return;
    }
    this.userService.getAvailableRooms(
      this.hotelId,
      this.bookingData.checkInDate,
      this.bookingData.checkOutDate
    ).subscribe({
      next: (rooms) => {
        this.filteredRooms = rooms;
      },
      error: () => {
        this.filteredRooms = [];
      }
    });
  }

  getRoomsForHotel() {
    this.userService.getRoomsByHotel(this.hotelId).subscribe({
      next: (response) => {
        this.rooms = response;
        this.filteredRooms = this.rooms.filter(room => room.availability); // ✅ Direct filtering
      },
      error: () => {
        this.filteredRooms = [];
      }
    });
  }
  

  filterAvailableRooms() {
    if (!this.bookingData.checkInDate || !this.bookingData.checkOutDate) {
      this.filteredRooms = this.rooms;
      return;
    }
    this.filteredRooms = this.rooms.filter(room => room.available !== false);
  }

  selectRoom(room: any) {
    this.selectedRoom = room;
    setTimeout(() => {
      if (this.bookingSummary) {
        this.bookingSummary.nativeElement.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }
    }, 100);
  }

  calculateTotalPrice() {
    if (!this.bookingData.checkInDate || !this.bookingData.checkOutDate || !this.selectedRoom) {
      this.totalPrice = 0; 
      this.numberOfDays = 0;
      return;
    }

    const checkIn = new Date(this.bookingData.checkInDate);
    const checkOut = new Date(this.bookingData.checkOutDate);

    if (checkOut <= checkIn) {
      alert("Check-out date must be later than check-in date.");
      this.totalPrice = 0;
      this.numberOfDays = 0;
      return;
    }

    const timeDifference = checkOut.getTime() - checkIn.getTime();
    this.numberOfDays = Math.ceil(timeDifference / (1000 * 3600 * 24));
    this.totalPrice = this.selectedRoom.price * this.numberOfDays;
  }

  openBookingModal() {
    if (!this.selectedRoom || !this.bookingData.checkInDate || !this.bookingData.checkOutDate) {
      alert("Please select a room and choose check-in/check-out dates before booking.");
      return;
    }
    // Re-check availability before showing modal
    this.userService.getAvailableRooms(
      this.hotelId,
      this.bookingData.checkInDate,
      this.bookingData.checkOutDate
    ).subscribe({
      next: (rooms) => {
        const stillAvailable = rooms.some(room => room.roomId === this.selectedRoom.roomId);
        if (!stillAvailable) {
          alert("Sorry, this room has just been booked by someone else. Please select another room.");
          this.onDateChange();
          return;
        }
        this.calculateTotalPrice();
        this.showModal = true;
      },
      error: () => {
        alert("Could not verify room availability. Please try again.");
      }
    });
  }

  onProceedToPayment(redeemedPoints: number) {
    this.bookingData.loyaltyPoints = redeemedPoints;
    this.showModal = false;
    this.bookRoom();
  }

  redirectToPayment() {
    if (!this.paymentUrl) {
      alert("Payment URL not available. Please try again.");
      return;
    }
    window.location.href = this.paymentUrl;
  }

  closeBookingDetails() {
    this.showModal = false;
  }

  bookRoom() {
    this.calculateTotalPrice();
    this.bookingData.hotelId = this.hotelId;
    this.bookingData.roomId = this.selectedRoom.roomId;
    this.bookingData.totalPrice = this.totalPrice-(((this.bookingData.loyaltyPoints)*20)/100);

    this.userService.createBooking(this.bookingData).subscribe({
      next: (response) => {
        this.paymentUrl = response.paymentUrl;
        this.redirectToPayment();
      },
      error: () => {
        alert("Failed to book room. Please try again.");
      }
    });
  }

  handlePaymentResponse(response: any) {
    if (response.status === "CONFIRMED") {
      this.bookingId = response.bookingId;
      this.paymentSuccess = true;
      this.totalPrice = response.totalAmount;
    } else {
      this.paymentFailed = true;
    }
  }

  redirectToBookingPage() {
    window.location.href = `http://localhost:4200/user/booking/${this.bookingId}`;
  }

  closePopup() {
    this.paymentSuccess = false;
    this.paymentFailed = false;
  }
}