import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ReviewServiceService {
  private apiUrl = 'http://localhost:8082/api/Reviews';

  constructor(private http: HttpClient) {}

  getReviewsByHotel(hotelId: number): Observable<any[]> {
    return this.http.get<any[]>(`${this.apiUrl}/hotel/${hotelId}`);
  }

  getReviewsByUser(userId: number): Observable<any[]> {
    return this.http.get<any[]>(`${this.apiUrl}/user/${userId}`);
  }

  updateReview(reviewId: number, review: any) {
    return this.http.put<any>(`${this.apiUrl}/updateReview/${reviewId}`, review);
  }

  postReview(review: any): Observable<any> {
    return this.http.post<any>(`${this.apiUrl}/postReview`, review);
  }

  deleteReview(reviewId: number): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/${reviewId}`);
  }

  deleteReviewsByHotel(hotelId: number): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/hotel/${hotelId}`);
  }
  // review-service.service.ts
getAverageRatingByHotel(hotelId: number) {
  return this.http.get<number>(`${this.apiUrl}/hotel/${hotelId}/average-rating`);
}
}