import { Component, Input, OnInit } from '@angular/core';
import { ReviewServiceService } from './review-service.service';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-review-details',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './review-details.component.html',
  styleUrls: ['./review-details.component.css']
})
export class ReviewDetailsComponent implements OnInit {
  @Input() hotelId: number = 0;
  @Input() userId: number = 0;

  reviews: any[] = [];
  displayedReviews: any[] = [];
  showAllReviews: boolean = false;

  userReview: any = null;
  newReview: any = { rating: 5, comment: '' };
  isEditing: boolean = false;
  averageRating: number = 0;

  stars: number[] = [1, 2, 3, 4, 5];

  constructor(private reviewService: ReviewServiceService) {}

  ngOnInit() {
    this.loadReviews();
    this.loadAverageRating();
  }

  loadReviews() {
    if (this.hotelId) {
      this.reviewService.getReviewsByHotel(this.hotelId).subscribe(data => {
        this.reviews = data;
        console.log(this.reviews);
        console.log("hello")
        this.userReview = this.reviews.find(r => r.user?.userId === this.userId) || null;
        if (this.userReview) {
          this.newReview = { rating: this.userReview.rating, comment: this.userReview.comment };
        } else {
          this.newReview = { rating: 5, comment: '' };
        }
        this.updateDisplayedReviews();
      });
    }
  }

  updateDisplayedReviews() {
    this.displayedReviews = this.showAllReviews ? this.reviews : this.reviews.slice(0, 2);
  }

  showMoreReviews() {
    this.showAllReviews = true;
    this.updateDisplayedReviews();
    setTimeout(() => {
      const el = document.getElementById('reviews-section');
      if (el) el.scrollIntoView({ behavior: 'smooth' });
    }, 100);
  }

  loadAverageRating() {
    if (this.hotelId) {
      this.reviewService.getAverageRatingByHotel(this.hotelId).subscribe(avg => {
        this.averageRating = avg;
      });
    }
  }

  setRating(rating: number) {
    this.newReview.rating = rating;
  }

  postOrUpdateReview() {
    if (this.userReview) {
      const updated = {
        ...this.userReview,
        rating: this.newReview.rating,
        comment: this.newReview.comment,
        hotel: { hotelId: this.hotelId },
        user: { userId: this.userId }
      };
      this.reviewService.updateReview(this.userReview.reviewId, updated).subscribe(() => {
        this.isEditing = false;
        this.loadReviews();
        this.loadAverageRating();
      });
    } else {
      const review = {
        ...this.newReview,
        hotel: { hotelId: this.hotelId },
        user: { userId: this.userId }
      };
      this.reviewService.postReview(review).subscribe(() => {
        this.loadReviews();
        this.loadAverageRating();
      });
    }
  }

  editReview() {
    this.isEditing = true;
    this.newReview = { rating: this.userReview.rating, comment: this.userReview.comment };
  }

  cancelEdit() {
    this.isEditing = false;
    this.newReview = { rating: this.userReview.rating, comment: this.userReview.comment };
  }

  deleteReview(reviewId: number) {
    this.reviewService.deleteReview(reviewId).subscribe(() => {
      this.userReview = null;
      this.isEditing = false;
      this.loadReviews();
      this.loadAverageRating();
    });
  }
}