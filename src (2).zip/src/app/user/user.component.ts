import { Component, CUSTOM_ELEMENTS_SCHEMA, OnInit } from '@angular/core';
import { UserService } from './user.service';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { ProfileComponent } from './profile/profile.component';
@Component({
  selector: 'app-user',
  imports: [FormsModule, CommonModule, RouterModule],
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css'],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class UserComponent implements OnInit {
  hotels: any[] = [];
  filteredHotels: any[] = [];
  currentPage: number = 1;
  pageSize: number = 8;

  filterCriteria = {
    location: '',
    amenity: '',
    name: '',
    checkInDate: '',
    checkOutDate: ''
  };

  constructor(private userService: UserService) {}

  dateError: boolean = false;
today: string = '';

ngOnInit() {
  this.today = new Date().toISOString().split('T')[0];
  this.getAllHotels();
}
validateDates() {
  const { checkInDate, checkOutDate } = this.filterCriteria;
  this.dateError = !!(checkInDate && checkOutDate && checkOutDate <= checkInDate);
}
  getAllHotels() {
    this.userService.getAllHotels().subscribe({
      next: (response) => {
        this.hotels = response;
        this.filteredHotels = response; // ✅ Initialize filtered list
      },
      error: (error) => {
        console.error("Error fetching hotels:", error);
      }
    });
  }
  get paginatedHotels() {
    const start = (this.currentPage - 1) * this.pageSize;
    return this.filteredHotels.slice(start, start + this.pageSize);
  }
  
  get totalPages() {
    return Math.ceil(this.filteredHotels.length / this.pageSize);
  }

  goToPage(page: number) {
    if (page < 1 || page > this.totalPages) return;
    this.currentPage = page;
  }

  nextPage() {
    if (this.currentPage < this.totalPages) {
      this.currentPage++;
    }
  }
  prevPage() {
    if (this.currentPage > 1) {
      this.currentPage--;
    }
  }
  applyFilters() {
    this.filteredHotels = this.hotels.filter(hotel => {
      const matchesLocation = this.filterCriteria.location
        ? hotel.location.toLowerCase().includes(this.filterCriteria.location.toLowerCase())
        : true;
      const matchesAmenity = this.filterCriteria.amenity
        ? hotel.amenities && hotel.amenities.some((a: string) =>
            a.toLowerCase().includes(this.filterCriteria.amenity.toLowerCase())
          )
        : true;
      return matchesLocation && matchesAmenity;
    });
  }
  searchByName() {
    const nameInput = this.filterCriteria.name.trim().toLowerCase();
    if (nameInput === '') {
      this.filteredHotels = this.hotels;
      return;
    }
    // Filter locally for partial match
    this.filteredHotels = this.hotels.filter(hotel =>
      hotel.name && hotel.name.toLowerCase().includes(nameInput)
    );
  }

  // searchByName() {
  //   if (this.filterCriteria.name.trim() === '') {
  //     this.filteredHotels = this.hotels;
  //     return;
  //   }
  //   this.userService.searchHotelByName(this.filterCriteria.name).subscribe({
  //     next: (hotels) => this.filteredHotels = hotels,
  //     error: (err) => console.error('Error searching by name:', err)
  //   });
  // }
  
  searchByDate() {
    const { checkInDate, checkOutDate } = this.filterCriteria;
    if (!checkInDate || !checkOutDate) {
      alert('Please select both check-in and check-out dates.');
      return;
    }
    this.userService.searchHotelsWithAvailableRooms(checkInDate, checkOutDate).subscribe({
      next: (hotels) => this.filteredHotels = hotels,
      error: (err) => console.error('Error searching by date:', err)
    });
  }
}
