import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({ providedIn: 'root' })
export class BookingHistoryService {
  constructor(private http: HttpClient) {}

  getBookingsByUser(userId: string) {
    return this.http.get<any[]>(`http://localhost:8082/api/client/bookings/user/${userId}/history`);
  }
}