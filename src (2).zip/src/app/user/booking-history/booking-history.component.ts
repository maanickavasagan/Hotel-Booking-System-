import { Component, OnInit } from '@angular/core';
import { BookingHistoryService } from './booking-history.service';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-booking-history',
  imports: [CommonModule],
  templateUrl: './booking-history.component.html',
  styleUrls: ['./booking-history.component.css']
})
export class BookingHistoryComponent implements OnInit {
  userId: string | null = null;
  bookings: any[] = [];

  constructor(private bookingHistoryService: BookingHistoryService) {}

  ngOnInit(): void {
    console.log("working");
    const token = localStorage.getItem('jwtToken');
    console.log("Token:", token); // Log the token to check if it's being retrieved correctly
    if (token) {
      try {
        const decoded = this.decodeToken(token);
        console.log("Decoded Token:", decoded); // Log the decoded token to check its contents
        this.userId = decoded.userId || null;
        console.log("User ID from token:", this.userId); // Log the user ID to check if it's being set correctly
        if (this.userId) {
          this.bookingHistoryService.getBookingsByUser(this.userId).subscribe({
            next: (data) => {
              console.log('API Response:', data); // Log the API response
              this.bookings = data;
            },
            error: (err) => {
              console.error('API Error:', err);
              this.bookings = [];
            }
          });
        }
      } catch (error) {
        console.error("Error decoding token:", error);
      }
    }
  }
  // Add this method to your component
isUpcoming(checkOutDate: string): boolean {
  return new Date(checkOutDate) >= new Date();
}
decodeToken(token: string): any {
  const payload = token.split('.')[1];
  const base64 = payload.replace(/-/g, '+').replace(/_/g, '/');
  const decodedPayload = atob(base64);
  return JSON.parse(decodedPayload);
}
}
