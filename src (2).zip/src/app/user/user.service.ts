import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({providedIn: 'root'})
export class UserService {
  private apiUrl = 'http://localhost:8082';

  constructor(private http: HttpClient) {}

  getAllHotels(): Observable<any> {
    return this.http.get(`${this.apiUrl}/MANAGER/admin`);
  }
  getRoomsByHotel(hotelId: number | undefined): Observable<any> {
    if (hotelId === undefined || hotelId <= 0) {
      console.error("Invalid hotelId provided.");
      return new Observable(); // ✅ Return empty observable instead of making an API call
    }
    return this.http.get(`http://localhost:8082/rooms/getAllRoomsByHotelId/${hotelId}`);
  }

  createBooking(bookingData: any): Observable<any> {
    console.log(bookingData.totalAmount);
    const headers = { 'Content-Type': 'application/json', 'Authorization': localStorage.getItem('jwtToken') || '' };
    return this.http.post(`http://localhost:8082/api/client/bookings/create`, bookingData, { headers });
  }

 
searchHotelByName(name: string): Observable<any> {
  return this.http.get(`${this.apiUrl}/MANAGER/search/name?name=${encodeURIComponent(name)}`);
}

searchHotelsWithAvailableRooms(checkInDate: string, checkOutDate: string): Observable<any> {
  return this.http.get(`${this.apiUrl}/hotels/search/available?checkInDate=${checkInDate}&checkOutDate=${checkOutDate}`);
}
// ...existing code...
  
// * Get available rooms for a hotel and date range
// */
getAvailableRooms(hotelId: number, checkInDate: string, checkOutDate: string): Observable<any[]> {
 return this.http.get<any[]>(
   `http://localhost:8082/rooms/available`,
   {
     params: {
       hotelId: hotelId.toString(),
       checkInDate,
       checkOutDate
     }
   }
 );

}
getUserIdByEmail(email: string): Observable<number> {
  return this.http.get<number>(`http://localhost:8082/api/userIdByEmail/${email}`);
}
  bookRoom(room: any): Observable<any> {
    const headers = new HttpHeaders({ 'Authorization': localStorage.getItem('jwtToken') || '', 'Content-Type': 'application/json' });
    return this.http.post(`${this.apiUrl}/rooms/bookRoom`, room, { headers });
  }

}
