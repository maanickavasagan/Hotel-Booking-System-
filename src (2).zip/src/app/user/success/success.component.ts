import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-success',
  template: `
    <h2>Success! Your action was completed.</h2>
    <p>Redirecting to user page...</p>
  `
})
export class SuccessComponent implements OnInit {
  constructor(private router: Router) {}

  ngOnInit() {
    setTimeout(() => {
      this.router.navigate(['/user']);
    }, 2000); 
  }
}