import { Component, OnInit } from '@angular/core';
import { ProfileService } from './profile.service';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-profile',
  imports: [CommonModule, FormsModule],
  templateUrl: './profile.component.html',
  styleUrl: './profile.component.css'
})
export class ProfileComponent implements OnInit {
  
  email: string = '';
  userId: number | null = null;
  user: any = {};
  redeemablePoints: number = 0;
  showPasswordChange: boolean = false;
  oldPassword: string = '';
  newPassword: string = '';
  confirmPassword: string = '';
  passwordMismatch: boolean = false;

  constructor(private profileService: ProfileService) {}

  ngOnInit() {
    this.email = localStorage.getItem('email') || '';
    if (this.email) {
      this.fetchUserIdAndData(this.email);
    }
  }

  private fetchUserIdAndData(email: string): void {
    this.profileService.getUserIdByEmail(email).subscribe({
      next: (id: number) => {
        this.userId = id;
        this.fetchUserData(id);
        this.fetchRedeemablePoints(id);
      },
      error: (err) => {
        console.error('Error fetching user ID:', err);
      }
    });
  }

  private fetchUserData(userId: number): void {
    this.profileService.getUserById(userId).subscribe({
      next: (userData: any) => {
        this.user = userData;
      },
      error: (err) => {
        console.error('Error fetching user data:', err);
      }
    });
  }

  private fetchRedeemablePoints(userId: number): void {
    this.profileService.getRedeemablePoints(userId).subscribe({
      next: (points: number) => {
        this.redeemablePoints = points;
      },
      error: (err) => {
        console.error('Error fetching redeemable points:', err);
      }
    });
  }

  togglePasswordChange(): void {
    this.showPasswordChange = !this.showPasswordChange;
  }

  changePassword(): void {
    if (this.newPassword !== this.confirmPassword) {
      this.passwordMismatch = true;
      return;
    }
    this.passwordMismatch = false;

    if (this.email) {
      this.profileService.changePassword(this.email, this.oldPassword, this.newPassword).subscribe({
        next: (response: any) => {
          console.log('Password changed successfully:', response.message);
          alert(response.message);
          this.showPasswordChange = false;
        },
        error: (err) => {
          console.error('Error changing password:', err);
          alert('Failed to change password. Please try again.');
        }
      });
    } else {
      console.error('Email is null. Cannot change password.');
      alert('Email is not available. Cannot change password.');
    }
  }
}