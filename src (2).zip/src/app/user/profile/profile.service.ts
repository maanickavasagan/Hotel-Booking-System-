import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ProfileService {

  constructor(private http: HttpClient) { }

  getUserIdByEmail(email: string): Observable<number> {
    return this.http.get<number>(`http://localhost:8082/api/userIdByEmail/${email}`);
  }
  getUserById(userId: number): Observable<any> {
    return this.http.get<any>(`http://localhost:8082/api/${userId}`);
  }
  changePassword(email:string, oldPassword: string, newPassword: string): Observable<string> {
    const body = { email, oldPassword, newPassword };
    return this.http.post<any>('http://localhost:8082/api/change-password', body);
  }
  getRedeemablePoints(userId: number): Observable<number> {
    console.log(userId);
    return this.http.get<number>(`http://localhost:8082/api/loyalty/getRedeemablePoints/${userId}`);
  }
}
