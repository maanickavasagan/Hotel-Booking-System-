import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-failure',
  template: `
    <h2>Failure. Something went wrong.</h2>
    <p>Redirecting to user page...</p>
  `
})
export class FailureComponent implements OnInit {
  constructor(private router: Router) {}

  ngOnInit() {
    setTimeout(() => {
      this.router.navigate(['/user']);
    }, 2000); // Redirect after 2 seconds
  }
}