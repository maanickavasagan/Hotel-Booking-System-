import { CommonModule } from '@angular/common';
import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { Router, RouterModule, NavigationEnd } from '@angular/router';

@Component({
  selector: 'app-navbar',
  imports: [CommonModule, RouterModule],
  templateUrl: './navbar.component.html',
  styleUrl: './navbar.component.css'
})
export class NavbarComponent implements OnInit {
  isLoggedIn = false; // Set this based on your auth logic
  showLoginPopup = false;

  constructor(private router: Router, private cdr: ChangeDetectorRef) {}

  ngOnInit(): void {
    this.checkLogin();
    this.router.events.subscribe(event => {
      if (event instanceof NavigationEnd) {
        this.checkLogin();
        this.cdr.detectChanges();
      }
    });
  }

  
  checkLogin() {
    this.isLoggedIn = !!localStorage.getItem('jwtToken');

  }
  navigateWithAuth(route: string) {
    const jwt = localStorage.getItem('jwtToken'); // use 'jwtToken' for consistency
    if (jwt) {
      this.router.navigate([route]);
    } else {
      this.showLoginPopup = true;
    }
  }

  redirectToLogin() {
    this.showLoginPopup = false;
    this.router.navigate(['/auth/login']);
  }
  handleAuthAction(): void {
    if (this.isLoggedIn) {
      localStorage.removeItem('jwtToken');
      localStorage.removeItem('email');
      localStorage.removeItem('role');
      this.isLoggedIn = false;
      this.cdr.detectChanges();
      this.router.navigate(['/user']);
    } else {
      this.router.navigate(['auth/login']);
    }
  }
}