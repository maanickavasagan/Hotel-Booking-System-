import { Component, OnInit } from '@angular/core';
import { RoomService } from '../room.service';
import { HotelService } from '../hotel.service';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-rooms',
  imports: [FormsModule, CommonModule],
  templateUrl: './rooms.component.html',
  styleUrls: ['./rooms.component.css']
})
export class RoomsComponent implements OnInit {
  hotelId: number | null = null;
  newFeature: string = ''; // ✅ Temporary storage for feature input
  newRoom: any = {
    type: '',
    price: 0,
    availability: true,
    roomNumber:0,
    features: [] as string[], // ✅ Explicitly define as an array of strings
    hotel: { hotelId: null } // ✅ Ensure hotel ID is assigned correctly
  };
  errorMessage = '';

  constructor(private roomService: RoomService, private hotelService: HotelService) {}

  ngOnInit() {
    this.fetchHotelId();
  }

  fetchHotelId() {
    this.hotelService.getManagerHotel().subscribe(response => {
      console.log("Fetched hotel response:", response);
      if (response.hotel && response.hotel.hotelId) {
        this.hotelId = response.hotel.hotelId;
        this.newRoom.hotel.hotelId = this.hotelId; // ✅ Dynamically assign hotel ID
      } else {
        this.errorMessage = "No hotel found.";
      }
    }, error => {
      console.error("Error fetching hotel ID:", error);
      this.errorMessage = "Failed to fetch hotel details.";
    });
  }

  addFeature() {
    if (this.newFeature.trim() !== '') {
      this.newRoom.features.push(this.newFeature.trim());
      console.log("Feature added:", this.newRoom.features); // ✅ Debugging log
      this.newFeature = ''; // ✅ Clear input field
    } else {
      console.log("Empty feature input, not added.");
    }
  }

  addRoom() {
    if (!this.hotelId) {
      this.errorMessage = "Cannot add room, no hotel linked!";
      return;
    }
    console.log("Adding room with details:", this.newRoom); // ✅ Debugging log

    this.newRoom.hotel = { hotelId: this.hotelId }; // ✅ Ensure hotelId is correctly set

    console.log("Room object being sent:", JSON.stringify(this.newRoom, null, 2)); // ✅ Debugging log

    this.roomService.addRoom(this.newRoom).subscribe(response => {
      console.log("Room added successfully:", response);
      this.newRoom = {
        type: '',
        price: 0,
        availability: true,
        roomNumber: 0,
        features: [],
        hotel: { hotelId: this.hotelId }
      }; // Reset form
      alert("Room added successfully!");
    }, error => {
      console.error("Error adding room:", error);
      this.errorMessage = "Failed to add room.";
    });
  }
}
