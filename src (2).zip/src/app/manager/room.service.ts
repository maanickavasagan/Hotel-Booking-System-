import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class RoomService {
  private apiUrl = 'http://localhost:8082/rooms'; // ✅ API base URL

  constructor(private http: HttpClient) {}

  addRoom(room: any): Observable<any> {
    const headers = new HttpHeaders({
      'Authorization': localStorage.getItem('jwtToken') || '',
      'Content-Type': 'application/json'
    });
  
    return this.http.post(`http://localhost:8082/rooms/addRooms`, room, { headers });
  }
  deleteRoom(roomId: number): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/${roomId}`);
  }
  updateRoom(roomId: number, roomData: any): Observable<any> {
    return this.http.put<any>(`${this.apiUrl}/update/${roomId}`, roomData, {
      headers: { 'Content-Type': 'application/json' } // ✅ Ensures correct format
    });
  }
  
  
  

  // getRoomsByHotel(hotelId: number): Observable<any> {
  //   const headers = new HttpHeaders({ 'Authorization': localStorage.getItem('jwtToken') || '' });
  //   return this.http.get(`${this.apiUrl}/getAllRoomsByHotelId/${hotelId}`, { headers });
  // }
}
