import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { HotelService } from '../hotel.service';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-create-hotel',
  imports: [FormsModule, CommonModule],
  standalone: true,
  templateUrl: './create-hotel.component.html',
  styleUrls: ['./create-hotel.component.css']
})
export class CreateHotelComponent {
  hotel = { name: '', location: '', rooms: 0, amenities: [] as string[] }; // ✅ Explicitly typed array
  newAmenity: string = ''; // ✅ Storage for new amenities
  errorMessage = '';

  constructor(private hotelService: HotelService, private router: Router) {}

  addAmenity() {
    if (this.newAmenity.trim() !== '') {
      this.hotel.amenities.push(this.newAmenity.trim()); // ✅ Add amenity to list
      this.newAmenity = ''; // ✅ Clear input field
    }
  }

  createHotel() {
    this.hotelService.addHotel(this.hotel).subscribe({
      next: (response) => {
        console.log('Hotel created successfully:', response);
        alert('Hotel created successfully!');
        this.router.navigate(['/manager/manage-hotel']); // ✅ Redirect on success
      },
      error: (error) => {
        console.error('Error creating hotel:', error);
        this.errorMessage = 'Failed to create hotel. Please try again.';
      }
    });
  }
}






























// import { Component } from '@angular/core';
// import { Router } from '@angular/router';
// import { HotelService } from '../hotel.service';
// import { FormsModule } from '@angular/forms';
// import { CommonModule } from '@angular/common';

// @Component({
//   selector: 'app-create-hotel',
//   imports: [FormsModule,CommonModule],
//   standalone: true,
//   templateUrl: './create-hotel.component.html',
//   styleUrls: ['./create-hotel.component.css']
// })
// export class CreateHotelComponent {
//   hotel = { name: '', location: '', rooms: 0, amenities: [] }; // ✅ Includes amenities
//   newAmenity: string = ''; // ✅ Temporary storage for new amenities
//   errorMessage = '';

//   constructor(private hotelService: HotelService, private router: Router) {}
//   addAmenity() {
//     if (this.newAmenity.trim() !== '') {
//       this.hotel.amenities.push(this.newAmenity.trim()); // ✅ Push new amenity to the list
//       this.newAmenity = ''; // ✅ Clear the input field after adding
//     }
//   }
  
//   // addAmenity() {
//   //   if (this.newAmenity.trim() !== '') {
//   //       this.hotel.amenities.push(this.newAmenity.trim());
//   //       this.newAmenity = ''; // ✅ Clear input after adding
//   //   }
//   // }
//   createHotel() {
//     this.hotelService.addHotel(this.hotel).subscribe({
//       next: (response) => {
//         console.log('Hotel created successfully:', response);
//         alert('Hotel created successfully!');
//         this.router.navigate(['/manager/manage-hotel']); // ✅ Redirect after success
//       },
//       error: (error) => {
//         console.error('Error creating hotel:', error);
//         this.errorMessage = 'Failed to create hotel. Please try again.';
//       }
//     });
//   }
  

//   // createHotel() {
//   //   this.hotelService.addHotel(this.hotel).subscribe(response => {
//   //     console.log('Hotel created successfully:', response);
//   //     alert('Hotel created successfully!');
//   //     this.router.navigate(['/manager/manage-hotel']); // ✅ Redirect after success
//   //   }, error => {
//   //     console.error('Error creating hotel:', error);
//   //     this.errorMessage = 'Failed to create hotel. Please try again.';
//   //   });
//   // }
// }
