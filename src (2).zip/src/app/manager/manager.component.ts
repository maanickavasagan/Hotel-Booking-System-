import { Component, NgModule, OnInit } from '@angular/core';
import { Router, RouterModule } from '@angular/router';
import { HotelService } from './hotel.service';
import { BrowserModule } from '@angular/platform-browser';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-manager',
  imports: [RouterModule,CommonModule],
  templateUrl: './manager.component.html',
  styleUrls: ['./manager.component.css']
})
export class ManagerComponent implements OnInit {
  hotelExists: boolean = false;

  constructor(private hotelService: HotelService, private router: Router) {}

  ngOnInit() {
    this.checkHotelOwnership();
  }

 
  checkHotelOwnership() {
    this.hotelService.getHotelDetails().subscribe(response => {
      if (response?.message === "No hotel found") {
        this.hotelExists = false;
      } else if (response?.hotel) {
        this.hotelExists = true;
      }
    }, error => {
      if (error.status === 404) {
        console.log("No hotel found, setting hotelExists to false."); // ✅ Suppress unnecessary error logging
        this.hotelExists = false;
      } else {
        console.error("Unexpected error:", error); // ✅ Log only unexpected errors
      }
    });
  }
  
  

  navigateTo(path: string) {
    this.router.navigate([path]);
  }
}
