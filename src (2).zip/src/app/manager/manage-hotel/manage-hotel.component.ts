import { Component, OnInit } from '@angular/core';
import { HotelService } from '../hotel.service';
import { RoomService } from '../room.service';
import { Router, RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-manage-hotel',
  imports: [RouterModule, CommonModule, FormsModule],
  standalone: true,
  templateUrl: './manage-hotel.component.html',
  styleUrls: ['./manage-hotel.component.css']
})
export class ManageHotelComponent implements OnInit {
  featuresInput: string = "";
  confirmedBookings: any[] = [];
  hotel: any = null;
  rooms: any[] = [];
  hotelId: number | null = null;
  errorMessage = '';
  selectedRoom: any = {};

  constructor(private hotelService: HotelService, private roomService: RoomService) {}

  ngOnInit() {
    this.fetchHotelDetails();
    
    console.log("Calling fetchConfirmedBookings...");
    
}

  fetchConfirmedBookings(hotelId: number) {
    console.log("hotelId",hotelId);
    this.hotelService.getConfirmedBookings(hotelId).subscribe(
      (response: any) => {
        console.log("Confirmed Bookings:", response);
        this.confirmedBookings = response || [];
      },
      (error: any) => {
        console.error("Error fetching confirmed bookings:", error);
        this.errorMessage = "Failed to fetch confirmed bookings.";
      }
    );
  }
  fetchHotelDetails() {
    this.hotelService.getManagerHotel().subscribe(
      (response: any) => {
        if (response && response.hotel) {
          this.hotel = response.hotel;
          this.hotelId = response.hotel.hotelId;
          if (this.hotelId !== null) {
            this.fetchRooms(this.hotelId);
            console.log("Hotel ID:", this.hotelId);
            // booking of hotel
            if (this.hotelId !== null) {
              console.log("hotelId is not null, proceeding to fetch bookings.");
                this.fetchConfirmedBookings(this.hotelId);
                console.log("Confirmed bookings fetched successfully.");
            } else {
                console.error("hotelId is null, cannot fetch bookings.");
            }
          }
        } else {
          this.errorMessage = "No hotel found.";
        }
      },
      (error: any) => {
        console.error("Error fetching hotel details:", error);
        this.errorMessage = "Failed to fetch hotel details.";
      }
    );
  }

  fetchRooms(hotelId: number) {
    this.hotelService.getRoomsByHotel(hotelId).subscribe(
      (response: any) => {
        console.log("Fetched rooms:", response);
        this.rooms = response || [];
      },
      (error: any) => {
        console.error("Error fetching rooms:", error);
        this.errorMessage = "Failed to fetch rooms.";
      }
    );
  }

  openEditModal(room: any) {
    console.log("Editing Room:", room);
    if (room) {
      this.selectedRoom = { ...room };
      const modal = document.getElementById("editRoomModal");
      if (modal) {
        modal.classList.add("show");
        modal.style.display = "block";
        document.body.classList.add("modal-open");
      }
    } else {
      console.error("Error: Room is null or undefined!");
    }
  }
  addFeature() {
    if (this.featuresInput.trim() !== "") {
        this.selectedRoom.features.push(this.featuresInput.trim());
        this.featuresInput = "";
    }
}

  closeEditModal() {
    const modal = document.getElementById("editRoomModal");
    if (modal) {
      modal.classList.remove("show");
      modal.style.display = "none";
      document.body.classList.remove("modal-open");
    }
    this.selectedRoom = {};
  }

  updateRoom() {
    console.log("Sending Room Update:", this.selectedRoom); 
    
    if (this.selectedRoom.roomId && this.selectedRoom) {
      console.log("enter the console");
        this.roomService.updateRoom(this.selectedRoom.roomId, this.selectedRoom).subscribe(
            (updatedRoom) => {
                console.log(`Room ${updatedRoom.roomId} updated successfully.`);
                this.rooms = this.rooms.map(room => room.roomId === updatedRoom.roomId ? updatedRoom : room);
                this.closeEditModal();
            },
            (error: any) => {
                console.error("Update Error:", error);
                this.errorMessage = `Failed to update room: ${error.status} - ${error.statusText}`;
            }
        );
    }
}


  deleteRoom(roomId: number) {
    if (confirm("Are you sure you want to delete this room?")) {
      this.roomService.deleteRoom(roomId).subscribe(
        () => {
          console.log(`Room ${roomId} deleted successfully.`);
          this.rooms = this.rooms.filter(room => room.roomId !== roomId);
        },
        (error: any) => {
          console.error(`Error deleting room ${roomId}:`, error);
          this.errorMessage = "Failed to delete room.";
        }
      );
    }
  }
}
