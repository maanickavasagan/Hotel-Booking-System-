import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class HotelService {
  private apiUrl = 'http://localhost:8082/MANAGER'; // Adjust your API URL

  constructor(private http: HttpClient) {}

  // Get hotel details for the logged-in manager
  getHotelDetails(): Observable<any> {
    const headers = new HttpHeaders({ 'Authorization': localStorage.getItem('jwtToken') || '' });
    return this.http.get(`${this.apiUrl}/dashboard`, { headers });
  }

  getRoomsByHotel(hotelId: number): Observable<any> {
    const headers = new HttpHeaders({ 'Authorization': localStorage.getItem('jwtToken') || '' });
    return this.http.get(`http://localhost:8082/rooms/getAllRoomsByHotelId/${hotelId}`, { headers }); // ✅ Corrected API URL
  }
  
  getConfirmedBookings(hotelId: number): Observable<any[]> {
    return this.http.get<any[]>(`http://localhost:8082/api/client/bookings/confirmed/${hotelId}`);
  }
  
  getHotelById(hotelId: number): Observable<any> {
    const headers = new HttpHeaders({ 'Authorization': localStorage.getItem('jwtToken') || '' });
    return this.http.get(`${this.apiUrl}/${hotelId}`, { headers });
  }
  // 

  
  getManagerHotel(): Observable<any> {
    const headers = new HttpHeaders({ 'Authorization': localStorage.getItem('jwtToken') || '' });
    return this.http.get(`${this.apiUrl}/hotel`, { headers }); // ✅ Fetch manager's hotel without hotelId
  }
  
  
  

  
  addHotel(hotel: any): Observable<any> {
    const headers = new HttpHeaders({ 'Authorization': localStorage.getItem('jwtToken') || '', 'Content-Type': 'application/json' });
    return this.http.post(`${this.apiUrl}/addHotel`, hotel, { headers });
  }

  // Update hotel details
  updateHotel(hotel: any): Observable<any> {
    const headers = new HttpHeaders({ 'Authorization': localStorage.getItem('jwtToken') || '', 'Content-Type': 'application/json' });
    return this.http.put(`${this.apiUrl}/updateHotel/${hotel.hotelId}`, hotel, { headers });
  }
}
