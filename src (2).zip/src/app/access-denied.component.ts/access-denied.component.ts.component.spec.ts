import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AccessDeniedComponentTsComponent } from './access-denied.component.ts.component';

describe('AccessDeniedComponentTsComponent', () => {
  let component: AccessDeniedComponentTsComponent;
  let fixture: ComponentFixture<AccessDeniedComponentTsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AccessDeniedComponentTsComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AccessDeniedComponentTsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
