import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-access-denied.component.ts',
  imports: [],
  templateUrl: './access-denied.component.ts.component.html',
  styleUrl: './access-denied.component.ts.component.css'
})
export class AccessDeniedComponentTsComponent {
  constructor(private router: Router) {}

  closePopup() {
    this.router.navigate(['/']); // Redirect to homepage
  }
}
