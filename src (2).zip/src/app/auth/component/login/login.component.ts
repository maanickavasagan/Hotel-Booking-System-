import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../../service/auth.service';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-login',
  imports: [FormsModule],
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  email = '';
  password = '';

  constructor(private authService: AuthService, private router: Router) {}

  login() {
    this.authService.login(this.email, this.password).subscribe(response => {
      if (response?.token) {
        localStorage.setItem('jwtToken', `Bearer ${response.token}`); // Store token properly
        //localStorage.setItem('role', response.role); // Store role
        localStorage.setItem('email', this.email);
        this.redirectBasedOnRole(response.role);
      } else {
        alert('Invalid credentials!');
      }
    }, error => {
      console.log('Full Error Response:', error);
      alert('Login failed: ' + (error.error?.message || 'Unknown error'));
    });
  }
  
  redirectBasedOnRole(role: string) {
    switch (role) {
      case 'ADMIN':
        this.router.navigate(['/admin']);
        break;
      case 'MANAGER':
        this.router.navigate(['/manager']);
        break;
      default:
        this.router.navigate(['/user']);
    }
  }  // <-- **Fixed misplaced closing bracket**

  navigateToRegister() {
    this.router.navigate(['/auth/register']);
  }
}
