import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../../service/auth.service';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-register',
  imports: [FormsModule],
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent {
  name = '';
  email = '';
  password = '';
  contactNumber = '';

  constructor(private authService: AuthService, private router: Router) {}

  register() {
    const user = {
      name: this.name,
      email: this.email,
      password: this.password,
      contactNumber: this.contactNumber
    };
  
    console.log('Sending Registration Data:', user); // 
  
    this.authService.register(user).subscribe({
      next: (response) => {
        console.log('Registration Response:', response);
        alert('Registration successful! You can now log in.');
        this.router.navigate(['/auth/login']); 
      },
      error: (error) => {
        console.error('Registration Error:', error);
    
        // Check if the error status is 409 (Conflict) and handle accordingly
        if (error.status === 409) {
          alert('Registration failed: Email already exists. Please use a different email.');
        } else {
          alert('Registration failed: ');
        }
      }
    });
    
  }
  

  navigateToLogin() {
    this.router.navigate(['/auth/login']);
  }
}
