import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private loginUrl = 'http://localhost:8082/api/login';
  private registerUrl = 'http://localhost:8082/api/register';

  constructor(private http: HttpClient) {}

  login(email: string, password: string): Observable<any> {
    return this.http.post(this.loginUrl, { email, password }, {
      headers: new HttpHeaders({ 'Content-Type': 'application/json' })
    });
  }

  register(user: any): Observable<any> {
    return this.http.post(this.registerUrl, user, {
      headers: new HttpHeaders({ 'Content-Type': 'application/json' })
    });
  }

  storeUserData(token: string, role: string) {
    localStorage.setItem('jwtToken', token);
    localStorage.setItem('role', role);
  }

  getToken(): string | null {
    return localStorage.getItem('jwtToken');
  }

  getUserRole(): string | null {
    const token = this.getToken();
    if (token) {
      try {
        const payload = JSON.parse(atob(token.split('.')[1])); // Decode JWT payload
        return payload.role; // Extract the role
      } catch (error) {
        console.error('Error decoding token:', error);
        return null;
      }
    }
    return null;
  }

  isAuthenticated(): boolean {
    return !!this.getToken(); // Ensures user is authenticated if token exists
  }

  logout() {
    localStorage.removeItem('jwtToken');
    localStorage.removeItem('role');
  }
}
