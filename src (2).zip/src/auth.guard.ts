import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router } from '@angular/router';
import { AuthService } from './app/auth/service/auth.service';

@Injectable({
  providedIn: 'root'
})
export class RoleGuard implements CanActivate {
  constructor(private authService: AuthService, private router: Router) {}

  canActivate(route: ActivatedRouteSnapshot): boolean {
    const expectedRole = route.data['expectedRole']; // Get expected role from route config
    const userRole = this.authService.getUserRole(); // Get role from JWT

    if (userRole === expectedRole) {
      return true; // Allow access if roles match
    } else {
      this.router.navigate(['/access-denied']); // Redirect unauthorized users
      return false;
    }
  }
}
